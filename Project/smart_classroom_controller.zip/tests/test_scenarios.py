"""Regression tests for schedule-based occupancy (ScenarioManager).

Guards against the classic bug where the first schedule entry with a 24 h
"empty" duration swallows the whole day and occupancy is always 0.
"""
from datetime import datetime

from iot_simulator.scenarios import ScenarioManager


class TestScenarioSchedule:
    def setup_method(self):
        self.manager = ScenarioManager()

    def test_normal_day_lecture_has_occupancy(self):
        # 10:00 is inside the 09:00 lecture period of normal_day
        occ = self.manager.get_occupancy_at_time(
            "normal_day", datetime(2025, 1, 1, 10, 0, 0)
        )
        assert occ > 0, "normal_day at 10:00 must be occupied (lecture period)"

    def test_normal_day_empty_before_schedule(self):
        # 06:00 is before the first entry (7:30 empty) -> nobody present
        occ = self.manager.get_occupancy_at_time(
            "normal_day", datetime(2025, 1, 1, 6, 0, 0)
        )
        assert occ == 0

    def test_normal_day_break_is_partial(self):
        # 11:00-11:30 is the break period -> 20 % of base occupancy
        occ = self.manager.get_occupancy_at_time(
            "normal_day", datetime(2025, 1, 1, 11, 15, 0)
        )
        assert 0 < occ < 30

    def test_empty_weekend_stays_empty(self):
        occ = self.manager.get_occupancy_at_time(
            "empty_weekend", datetime(2025, 1, 1, 12, 0, 0)
        )
        assert occ == 0

    def test_after_last_period_is_empty(self):
        # normal_day's last entry is 14:00 empty (24 h) -> evening is empty
        occ = self.manager.get_occupancy_at_time(
            "normal_day", datetime(2025, 1, 1, 18, 0, 0)
        )
        assert occ == 0
