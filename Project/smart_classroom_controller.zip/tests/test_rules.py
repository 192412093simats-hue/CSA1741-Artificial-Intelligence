"""Pytest suite for the Smart Classroom Controller.

Run with: .venv\Scripts\python.exe -m pytest -v
"""

from datetime import datetime, timedelta
from typing import Optional

import numpy as np
import pytest

from controller.rules import RuleEngine
from controller.filters import (
    SensorFilterPipeline,
    SensorValidator,
    MovingAverageFilter,
    MedianFilter,
    DropoutHandler,
)
from iot_simulator.classroom import Classroom
from iot_simulator.scenarios import ScenarioManager
from controller.agent import ControllerAgent

ALL_SCENARIOS = [
    "normal_day",
    "exam_day",
    "hot_afternoon",
    "empty_weekend",
    "power_saving_mode",
    "faulty_sensor",
]


class Reading:
    """Minimal pseudo-reading for unit tests (object-attribute access)."""

    def __init__(self, lux=None, occupancy=None, temperature=None, co2=None):
        self.lux = lux
        self.occupancy = occupancy
        self.temperature = temperature
        self.co2 = co2


# ---------------------------------------------------------------------------
# Unit tests: rule engine, hysteresis, dwell, vacancy
# ---------------------------------------------------------------------------
class TestRuleEngine:
    def test_lights_low_lux_and_occupied_turns_on(self):
        e = RuleEngine()
        r = Reading(lux=200.0, occupancy=10)
        results = e.evaluate_lights("front", r, datetime.now())
        assert any(rr.action == "on" for rr in results)

    def test_lights_high_lux_turns_off(self):
        e = RuleEngine()
        r = Reading(lux=900.0, occupancy=10)
        results = e.evaluate_lights("front", r, datetime.now())
        assert any(rr.action == "off" for rr in results)

    def test_vacancy_timeout_turns_lights_off(self):
        e = RuleEngine()
        r = Reading(lux=200.0, occupancy=0)
        results = e.evaluate_lights("front", r, datetime.now())
        assert any(rr.action == "off" for rr in results)

    def test_no_lux_low_and_occupied_no_light_on(self):
        e = RuleEngine()
        r = Reading(lux=600.0, occupancy=10)
        results = e.evaluate_lights("front", r, datetime.now())
        assert not any(rr.rule_name == "lights_on_low_lux" for rr in results)

    def test_none_values_do_not_crash(self):
        e = RuleEngine()
        r = Reading(lux=None, occupancy=None)
        results = e.evaluate_lights("front", r, datetime.now())
        assert results == []

    def test_fans_hot_temp_turns_on(self):
        e = RuleEngine()
        r = Reading(temperature=29.0, occupancy=10, co2=800)
        results = e.evaluate_fans("front", r, datetime.now())
        assert any("speed_" in rr.action and rr.action != "speed_0" for rr in results)

    def test_fans_cold_temp_turns_off(self):
        e = RuleEngine()
        r = Reading(temperature=22.0, occupancy=0, co2=400)
        results = e.evaluate_fans("front", r, datetime.now())
        assert any(rr.action == "speed_0" for rr in results)

    def test_none_fan_temp_returns_empty(self):
        e = RuleEngine()
        r = Reading(temperature=None, occupancy=10, co2=800)
        results = e.evaluate_fans("front", r, datetime.now())
        assert results == []

    def test_dwell_time_blocks_repeated_changes(self):
        e = RuleEngine()
        base = datetime.now()
        r1 = Reading(lux=200.0, occupancy=10)
        res1 = e.evaluate_lights("front", r1, base)
        r2 = Reading(lux=200.0, occupancy=10)
        res2 = e.evaluate_lights("front", r2, base + timedelta(seconds=5))
        assert len(res1) >= 1
        assert len(res2) == 0  # dwell time not elapsed

    def test_dwell_time_allows_change_after_threshold(self):
        e = RuleEngine()
        base = datetime.now()
        r1 = Reading(lux=200.0, occupancy=10)
        e.evaluate_lights("front", r1, base)
        r2 = Reading(lux=600.0, occupancy=10)
        res = e.evaluate_lights("front", r2, base + timedelta(seconds=60))
        assert any(rr.action == "off" for rr in res)

    def test_dropout_falls_back_to_last_good_value(self):
        e = RuleEngine()
        base = datetime.now()
        # First valid reading establishes last good (no prior action yet)
        e.last_good["lux_front"] = 200.0
        e.last_good["occupancy_front"] = 10
        # Dropout: both None → should fall back to last good and still fire
        res = e.evaluate_lights("front", Reading(lux=None, occupancy=None), base)
        assert any(rr.action == "on" for rr in res), "dropout should fall back to last good value"

    def test_dwell_with_custom_vacancy_timeout(self):
        e = RuleEngine()
        base = datetime.now()
        r1 = Reading(lux=200.0, occupancy=10)
        e.evaluate_lights("front", r1, base)
        r2 = Reading(lux=600.0, occupancy=10)
        res = e.evaluate_lights("front", r2, base + timedelta(seconds=60))
        assert any(rr.action == "off" for rr in res)


# ---------------------------------------------------------------------------
# Unit tests: filters, dropout handling (None)
# ---------------------------------------------------------------------------
class TestFilters:
    def test_validator_rejects_out_of_range_and_none(self):
        assert SensorValidator.validate(None, "lux") is False
        assert SensorValidator.validate(-100, "lux") is False
        assert SensorValidator.validate(400.0, "lux") is True
        assert SensorValidator.validate(None, "occupancy") is False

    def test_median_filter_rejects_none(self):
        mf = MedianFilter()
        assert mf.update("a", None) is None

    def test_moving_average_smooths_values(self):
        ma = MovingAverageFilter(window_size=3)
        ma.update("a", 10.0)
        assert ma.update("a", 20.0) == 15.0
        assert ma.update("a", 30.0) == 20.0

    def test_dropout_handler_uses_last_good_within_timeout(self):
        dh = DropoutHandler(timeout_seconds=30)
        t = datetime.now()
        assert dh.update("a", 400.0, t) == 400.0
        assert dh.update("a", None, t + timedelta(seconds=10)) == 400.0  # fallback

    def test_dropout_handler_returns_none_after_timeout(self):
        dh = DropoutHandler(timeout_seconds=5)
        t = datetime.now()
        dh.update("a", 400.0, t)
        assert dh.update("a", None, t + timedelta(seconds=10)) is None

    def test_pipeline_preserves_last_good_on_none(self):
        p = SensorFilterPipeline()
        t = datetime.now()
        r1 = p.process("lux", "front", 400.0, t)
        assert r1.filtered == 400.0 and not r1.dropped
        r2 = p.process("lux", "front", None, t + timedelta(seconds=10))
        assert r2.filtered == 400.0  # fell back to last good
        assert r2.dropped is False  # fallback handled it, so not considered "dropped"


# ---------------------------------------------------------------------------
# Integration tests: all six scenarios run end to end
# ---------------------------------------------------------------------------
class TestScenariosIntegration:
    def test_scenarios_list_has_six(self):
        names = ScenarioManager().get_scenarios_list()
        assert set(ALL_SCENARIOS).issubset(set(names))

    def test_all_scenarios_run_without_crash(self):
        for name in ALL_SCENARIOS:
            classroom = Classroom()
            classroom.set_scenario(name)
            classroom.reset()
            agent = ControllerAgent(mode="auto")
            changes = classroom.step(60)
            noisy = changes[0][0]
            gt = changes[0][1]
            decision = agent.process_readings(noisy, classroom.current_time, ground_truth={
                f"LIGHT-{r.zone}": (r.occupancy > 0 and r.lux < 300) for r in gt
            })
            assert decision is not None

    def test_empty_weekend_keeps_devices_off(self):
        classroom = Classroom()
        classroom.set_scenario("empty_weekend")
        classroom.reset()
        agent = ControllerAgent(mode="auto")
        changes = classroom.step(60)
        decision = agent.process_readings(changes[0][0], classroom.current_time)
        lights_on = [c for c in decision.commands if c.device_type == "light" and c.params.get("on")]
        fans_on = [c for c in decision.commands if c.device_type == "fan" and c.params.get("on")]
        assert lights_on == []
        assert fans_on == []

    def test_deterministic_seed_reproducibility(self):
        timestamps = [datetime(2025, 1, 1, 8, 0, 0) + timedelta(minutes=i) for i in range(10)]
        results = []
        for _ in range(2):
            classroom = Classroom()
            classroom.set_scenario("normal_day")
            classroom.reset()
            agent = ControllerAgent(mode="auto")
            for ts in timestamps:
                readings = [classroom.generate_reading(z, ts, is_ground_truth=False) for z in ["front", "middle", "back"]]
                agent.process_readings(readings, ts)
            results.append([len(d.commands) for d in agent.history])
        assert results[0] == results[1], "same seeds/timestamps must reproduce identical decisions"


# ---------------------------------------------------------------------------
# UI smoke test: manual per-zone decisions (decide_zone_state)
# ---------------------------------------------------------------------------
class TestManualDecisions:
    def test_empty_zone_lights_off(self):
        from controller.decision import decide_zone_state
        d = decide_zone_state("front", 0, 600, 28, 400)
        assert d["light_on"] is False
        assert d["light_action"] == "off"

    def test_one_seat_low_lux_lights_on(self):
        from controller.decision import decide_zone_state
        d = decide_zone_state("front", 1, 100, 24, 400)
        assert d["light_on"] is True
        assert d["light_action"] == "on"

    def test_hot_occupied_fan_above_zero(self):
        from controller.decision import decide_zone_state
        d = decide_zone_state("front", 5, 600, 32, 800)
        assert d["fan_speed"] > 0

    def test_none_inputs_do_not_crash(self):
        from controller.decision import decide_zone_state
        d = decide_zone_state("front", None, None, None, None)
        assert d["light_on"] is False
        assert d["fan_speed"] == 0
