"""Smart Classroom Controller — simple mode-driven dashboard.

A single-page dashboard where you CHOOSE A MODE. In Manual mode you CLICK
SEATS to mark students present and the controller instantly decides which
lights and fans to turn on and shows the energy saved. In Auto mode the
simulator drives the classroom.

Page flow: sidebar -> header -> KPI row -> classroom hero -> decision log +
energy -> bottom metric strip -> Evaluation tab.
"""

import re
import sys
import time
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import streamlit as st

from iot_simulator.classroom import Classroom
from controller.agent import ControllerAgent
from controller.decision import decide_zone_state
from evaluation.run_evaluation import run_full_evaluation, save_results_json
from evaluation.report_generator import generate_all_reports
from evaluation.metrics import (
    compute_device_accuracy,
    compute_response_latency,
    compute_false_activation_rate,
)

from ui.theme import DARK, STYLESHEET
from ui.classroom import ZONES, render_classroom, render_outside_light_card
from ui.cards import kpi_row, decision_log_card, energy_card, bottom_strip

# =============================================================================
# Page configuration + one CSS block
# =============================================================================
st.set_page_config(
    page_title="Smart Classroom Controller",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)
st.markdown(STYLESHEET, unsafe_allow_html=True)

UI_SCENARIOS = ["Normal Day", "Exam Day", "Hot Afternoon", "Empty Weekend"]
UI_SCENARIO_KEYS = {
    "Normal Day": "normal_day",
    "Exam Day": "exam_day",
    "Hot Afternoon": "hot_afternoon",
    "Empty Weekend": "empty_weekend",
}
POWER_LIGHT_W = 60.0
POWER_FAN_W = 30.0
SEATS_PER_ZONE = 16


# =============================================================================
# Session state — ONE state object holds every number on the screen
# =============================================================================
def init_state() -> None:
    if "state" not in st.session_state:
        st.session_state.state = {
            "mode": "manual",
            "scenario": "Normal Day",
            "running": False,
            "outside_lux": 600.0,
            "room_temp": 28.0,
            "seats": {z: [False] * SEATS_PER_ZONE for z in ZONES},
            "devices": {},
            "decisions": [],
            "history": [],
            "eval_results": None,
            "ctrl_kwh": 0.0,
            "base_kwh": 0.0,
            "sim_time": None,
        }
    if "classroom" not in st.session_state:
        st.session_state.classroom = Classroom()
    if "controller" not in st.session_state:
        st.session_state.controller = ControllerAgent(mode="auto")


init_state()
STATE = st.session_state.state


# =============================================================================
# Helpers
# =============================================================================
def _clean_reason(text: str) -> str:
    """Round sensor floats to 1 dp and truncate to 60 chars for the log."""
    text = re.sub(r"(\d+\.\d{4,})\d+", lambda m: f"{float(m.group(1)):.1f}", text)
    return text[:60]


def _zone_occ(s) -> dict:
    return {z: sum(1 for x in STATE["seats"][z] if x) for z in ZONES}


def _total_occ() -> int:
    return sum(1 for z in ZONES for x in STATE["seats"][z] if x)


def run_manual_decision() -> None:
    """Event-driven Manual decision: run decide_zone_state ONCE per zone."""
    outside_lux = STATE["outside_lux"]
    temp = STATE["room_temp"]
    occ = _total_occ()
    co2 = 400 + 15 * occ
    now = datetime.now()
    decisions = []
    devices = {}
    for zone in ZONES:
        zone_occ = sum(1 for x in STATE["seats"][zone] if x)
        d = decide_zone_state(zone, zone_occ, outside_lux, temp, co2)
        devices[f"LIGHT-{zone}"] = {
            "on": d["light_on"],
            "brightness": 80 if d["light_on"] else 0,
        }
        devices[f"FAN-{zone}"] = {
            "on": d["fan_speed"] > 0,
            "speed": d["fan_speed"],
        }
        decisions.append({
            "time": now.strftime("%H:%M"),
            "action": f"{zone.capitalize()} lights {'ON' if d['light_on'] else 'OFF'}",
            "reason": d["light_reason"],
        })
        decisions.append({
            "time": now.strftime("%H:%M"),
            "action": f"{zone.capitalize()} fan speed {d['fan_speed']}",
            "reason": d["fan_reason"],
        })
    STATE["devices"] = devices
    STATE["decisions"] = decisions[-5:]


def toggle_seat(zone: str, idx: int) -> None:
    """on_click callback for one seat button: flip it, decide instantly."""
    STATE["seats"][zone][idx] = not STATE["seats"][zone][idx]
    run_manual_decision()


def _on_env_change() -> None:
    STATE["outside_lux"] = float(st.session_state.get("slider_lux", STATE["outside_lux"]))
    STATE["room_temp"] = float(st.session_state.get("slider_temp", STATE["room_temp"]))
    run_manual_decision()


def _fill_all() -> None:
    for z in ZONES:
        STATE["seats"][z] = [True] * SEATS_PER_ZONE
    run_manual_decision()


def _clear_all() -> None:
    for z in ZONES:
        STATE["seats"][z] = [False] * SEATS_PER_ZONE
    run_manual_decision()


def _reset_manual() -> None:
    STATE["seats"] = {z: [False] * SEATS_PER_ZONE for z in ZONES}
    STATE["outside_lux"] = 600.0
    STATE["room_temp"] = 28.0
    STATE["decisions"] = []
    STATE["devices"] = {}
    run_manual_decision()


def _reset_auto() -> None:
    st.session_state.classroom.reset()
    st.session_state.controller.reset()
    STATE["running"] = False
    STATE["decisions"] = []
    STATE["history"] = []
    STATE["devices"] = {}
    STATE["ctrl_kwh"] = 0.0
    STATE["base_kwh"] = 0.0


def run_auto_step() -> None:
    """Advance the simulator one minute and apply the controller's commands."""
    classroom = st.session_state.classroom
    controller = st.session_state.controller
    changes = classroom.step(60)
    if not changes:
        return
    noisy, gt = changes[0]
    gt_states = {}
    for r in gt:
        occ = r.occupancy if r.occupancy is not None else 0
        gt_states[f"LIGHT-{r.zone}"] = occ > 0 and (r.lux is not None and r.lux < 300)
        fan = 0
        if r.temperature is not None and r.occupancy is not None:
            fan = max(0, min(3, int(r.temperature - 24)))
        gt_states[f"FAN-{r.zone}"] = fan > 0

    decision = controller.process_readings(noisy, classroom.current_time, ground_truth=gt_states)
    for cmd in decision.commands:
        for dev in classroom.devices:
            if dev.device_id == cmd.device_id:
                dev.update(cmd.params)

    ctrl_w = sum(dev.get_power_watts() for dev in classroom.devices)
    base_w = 3 * POWER_LIGHT_W + 3 * POWER_FAN_W
    # watt-hours -> kilowatt-hours (60 s of runtime per step)
    STATE["ctrl_kwh"] += ctrl_w * 60 / 3600.0 / 1000.0
    STATE["base_kwh"] += base_w * 60 / 3600.0 / 1000.0
    STATE["sim_time"] = classroom.current_time
    STATE["history"].append({
        "readings": noisy,
        "gt": gt,
        "time": classroom.current_time,
        "devices": [d.to_dict() for d in classroom.devices],
    })

    STATE["devices"] = {
        dev.device_id: dict(dev.state) for dev in classroom.devices
    }

    # Newest-first decisions from this frame's commands.
    frame_decisions = []
    for cmd in decision.commands:
        if cmd.device_type == "light":
            label = f"{cmd.zone.capitalize()} lights {'ON' if cmd.params.get('on') else 'OFF'}"
        else:
            label = f"{cmd.zone.capitalize()} fan speed {int(cmd.params.get('speed', 0))}"
        frame_decisions.append({
            "time": classroom.current_time.strftime("%H:%M"),
            "action": label,
            "reason": _clean_reason(cmd.reason or ""),
        })
    if frame_decisions:
        STATE["decisions"] = (frame_decisions + STATE["decisions"])[:5]


def _auto_readings():
    classroom = st.session_state.classroom
    if STATE["history"]:
        return STATE["history"][-1]["readings"]
    now = classroom.current_time
    return [classroom.generate_reading(z, now, is_ground_truth=False) for z in ZONES]


def _sync_seats_from_sim() -> None:
    """Auto mode: mirror the simulator's per-zone occupancy into the seat grid."""
    for r in _auto_readings():
        occ = int(max(0, int(getattr(r, "occupancy", 0) or 0)))
        n = min(SEATS_PER_ZONE, occ)
        STATE["seats"][r.zone] = [True] * n + [False] * (SEATS_PER_ZONE - n)


# =============================================================================
# Metrics helper (reuses evaluation/metrics.py)
# =============================================================================
def compute_metrics(manual_mode: bool):
    s = st.session_state.state
    if manual_mode:
        gt_lights, gt_fans = {}, {}
        actual_lights, actual_fans = {}, {}
        for z in ZONES:
            occ = sum(1 for x in s["seats"][z] if x)
            d = decide_zone_state(z, occ, s["outside_lux"], s["room_temp"], 400 + 15 * occ)
            gt_lights[f"LIGHT-{z}"] = d["light_on"]
            gt_fans[f"FAN-{z}"] = d["fan_speed"] > 0
            actual_lights[f"LIGHT-{z}"] = bool(s["devices"].get(f"LIGHT-{z}", {}).get("on"))
            actual_fans[f"FAN-{z}"] = bool(s["devices"].get(f"FAN-{z}", {}).get("on"))
        la = compute_device_accuracy(actual_lights, gt_lights, "light")[0]
        fa = compute_device_accuracy(actual_fans, gt_fans, "fan")[0]
        acc = (la + fa) / 2.0
        actions = [{"device_id": k, "action": "on" if v else "off"} for k, v in actual_lights.items()]
        far = 0.0
        for z in ZONES:
            far += compute_false_activation_rate(actions, gt_lights, f"LIGHT-{z}", datetime.now())
        far /= len(ZONES)
        return f"{acc * 100:.0f}%", "--", f"{far * 100:.1f}%"

    # Auto mode
    if not s["history"]:
        return "--", "--", "--"
    last = s["history"][-1]
    readings = last["readings"]
    actual_lights, actual_fans, gt_lights, gt_fans = {}, {}, {}, {}
    for z in ZONES:
        actual_lights[f"LIGHT-{z}"] = bool(s["devices"].get(f"LIGHT-{z}", {}).get("on"))
        actual_fans[f"FAN-{z}"] = bool(s["devices"].get(f"FAN-{z}", {}).get("on"))
    for r in readings:
        occ = getattr(r, "occupancy", 0) or 0
        gt_lights[f"LIGHT-{r.zone}"] = occ > 0 and (r.lux is not None and r.lux < 300)
        fan = 0
        if r.temperature is not None and r.occupancy is not None:
            fan = max(0, min(3, int(r.temperature - 24)))
        gt_fans[f"FAN-{r.zone}"] = fan > 0

    la = compute_device_accuracy(actual_lights, gt_lights, "light")[0]
    fa = compute_device_accuracy(actual_fans, gt_fans, "fan")[0]
    acc = (la + fa) / 2.0

    actual_events = [{"timestamp": last["time"], "device_id": k} for k in actual_lights]
    gt_events = [{"timestamp": last["time"], "device_id": k} for k in gt_lights]
    lat = compute_response_latency(actual_events, gt_events)

    actions = [{"device_id": k, "action": "on" if v else "off"} for k, v in actual_lights.items()]
    far = 0.0
    for z in ZONES:
        far += compute_false_activation_rate(actions, gt_lights, f"LIGHT-{z}", last["time"])
    far /= len(ZONES)
    return f"{acc * 100:.0f}%", f"{lat.mean_latency_seconds:.1f}", f"{far * 100:.1f}%"


# =============================================================================
# Sidebar — only the controls the spec allows
# =============================================================================
with st.sidebar:
    st.markdown("### Smart Classroom Controller")
    mode_option = st.radio(
        "Mode",
        ["Manual - click the seats", "Auto - run simulation"],
        index=0 if STATE["mode"] == "manual" else 1,
    )
    new_mode = "manual" if mode_option.startswith("Manual") else "auto"
    if new_mode != STATE["mode"]:
        STATE["mode"] = new_mode
        if new_mode == "manual":
            _reset_manual()
        else:
            _reset_auto()
        st.rerun()

    if STATE["mode"] == "manual":
        st.slider(
            "Outside light (lux)", 0, 1000, int(STATE["outside_lux"]),
            key="slider_lux", on_change=_on_env_change,
        )
        st.slider(
            "Room temperature (°C)", 20, 40, int(STATE["room_temp"]),
            key="slider_temp", on_change=_on_env_change,
        )
        c1, c2 = st.columns(2)
        with c1:
            st.button("Fill all seats", use_container_width=True, on_click=_fill_all)
        with c2:
            st.button("Clear all seats", use_container_width=True, on_click=_clear_all)
    else:
        scenario = st.selectbox(
            "Scenario", UI_SCENARIOS,
            index=UI_SCENARIOS.index(STATE["scenario"]),
        )
        if scenario != STATE["scenario"]:
            STATE["scenario"] = scenario
            st.session_state.classroom.set_scenario(UI_SCENARIO_KEYS[scenario])
            st.session_state.classroom.reset()
            _reset_auto()
            st.rerun()

        c1, c2 = st.columns(2)
        with c1:
            if st.button("▶ Start", use_container_width=True, disabled=STATE["running"]):
                STATE["running"] = True
        with c2:
            if st.button("⏸ Pause", use_container_width=True, disabled=not STATE["running"]):
                STATE["running"] = False
        if st.button("🔄 Reset", use_container_width=True):
            _reset_auto()
            st.rerun()


# =============================================================================
# Main content: Live Dashboard + Evaluation tabs
# =============================================================================
manual = STATE["mode"] == "manual"
tab_live, tab_eval = st.tabs(["🏫 Live Dashboard", "📊 Evaluation"])

if not manual:
    _sync_seats_from_sim()

with tab_live:
    # ---- A. Header + mode chip -------------------------------------------
    if manual:
        outside_lux = STATE["outside_lux"]
    else:
        readings = _auto_readings()
        lux_vals = [r.lux for r in readings if getattr(r, "lux", None) is not None]
        outside_lux = sum(lux_vals) / len(lux_vals) if lux_vals else STATE["outside_lux"]

    zones_lit = sum(1 for z in ZONES if STATE["devices"].get(f"LIGHT-{z}", {}).get("on"))
    inside_lux = (outside_lux or 0) + 150 * zones_lit

    hc1, hc2 = st.columns([3, 1.2])
    with hc1:
        st.markdown(
            '<div class="hdr"><span class="hdr-icon">🎓</span>'
            '<div><div class="hdr-title">Smart Classroom Controller</div>'
            '<div class="hdr-sub">AI-Powered Rule-Based Lighting &amp; Fan Control</div>'
            '</div></div>',
            unsafe_allow_html=True,
        )
    with hc2:
        st.markdown(
            f'<div class="chips"><span class="mode-chip">Mode: {STATE["mode"].upper()}</span></div>',
            unsafe_allow_html=True,
        )

    # ---- B. KPI row (4 cards) --------------------------------------------
    temp = STATE["room_temp"]
    if manual:
        occupancy = _total_occ()
        co2 = 400 + 15 * occupancy
    else:
        readings = _auto_readings()
        occupancy = sum(max(0, int(getattr(r, "occupancy", 0) or 0)) for r in readings)
        tvals = [r.temperature for r in readings if getattr(r, "temperature", None) is not None]
        temp = sum(tvals) / len(tvals) if tvals else None
        covals = [r.co2 for r in readings if getattr(r, "co2", None) is not None]
        co2 = sum(covals) / len(covals) if covals else None
        outside_lux = (sum(lux_vals) / len(lux_vals)) if lux_vals else None

    st.markdown(
        kpi_row(
            occupancy,
            f"{int(round(inside_lux))}" if inside_lux is not None else "--",
            f"{temp:.1f}" if temp is not None else "--",
            f"{int(round(co2))}" if co2 is not None else "--",
        ),
        unsafe_allow_html=True,
    )

    # ---- C. Classroom hero ------------------------------------------------
    cl, cr = st.columns([3.2, 1])
    with cl:
        render_classroom(STATE, manual, toggle_seat)
    with cr:
        render_outside_light_card(outside_lux)

    # ---- D. Decision log + Energy ----------------------------------------
    d1, d2 = st.columns([2, 1])
    with d1:
        st.markdown(decision_log_card(STATE["decisions"]), unsafe_allow_html=True)
    with d2:
        if manual:
            ctrl_w = 0.0
            for z in ZONES:
                if STATE["devices"].get(f"LIGHT-{z}", {}).get("on"):
                    ctrl_w += POWER_LIGHT_W
                spd = int(STATE["devices"].get(f"FAN-{z}", {}).get("speed", 0) or 0)
                if spd > 0:
                    ctrl_w += POWER_FAN_W * spd / 3.0
            base_w = 3 * POWER_LIGHT_W + 3 * POWER_FAN_W
            pct = (base_w - ctrl_w) / base_w * 100 if base_w else 0.0
            st.markdown(energy_card(0, 0, True, pct, ctrl_w, base_w), unsafe_allow_html=True)
        else:
            pct = (STATE["base_kwh"] - STATE["ctrl_kwh"]) / STATE["base_kwh"] * 100 \
                if STATE["base_kwh"] else 0.0
            st.markdown(
                energy_card(STATE["base_kwh"], STATE["ctrl_kwh"], False, pct),
                unsafe_allow_html=True,
            )

    # ---- E. Bottom strip (3 metrics via evaluation/metrics.py) -----------
    accuracy, latency, false_rate = compute_metrics(manual)
    st.markdown(bottom_strip(accuracy, latency, false_rate), unsafe_allow_html=True)

    # Advance the simulation only AFTER the full frame renders.
    if not manual and STATE["running"]:
        run_auto_step()
        time.sleep(0.35)
        st.rerun()


# =============================================================================
# Evaluation tab — minimal per spec
# =============================================================================
with tab_eval:
    st.markdown("### Batch Evaluation")
    col1, col2 = st.columns(2)
    with col1:
        num_sims = st.number_input("Simulations per scenario", 1, 20, 3)
        sim_duration = st.number_input("Duration per simulation (minutes)", 10, 480, 60)
    with col2:
        eval_scenarios = st.multiselect("Scenarios", UI_SCENARIOS, default=UI_SCENARIOS)
        eval_seed = st.number_input("Seed", 0, 9999, 42)

    if st.button("Run evaluation", type="primary"):
        with st.spinner("Running evaluation..."):
            keys = [UI_SCENARIO_KEYS[n] for n in eval_scenarios] or list(UI_SCENARIO_KEYS.values())
            results = run_full_evaluation(
                scenarios=keys,
                num_simulations_per_scenario=int(num_sims),
                simulation_seconds=int(sim_duration) * 60,
                seed=int(eval_seed),
            )
            STATE["eval_results"] = results
            save_results_json(results)
            st.success("Evaluation complete!")

    if STATE["eval_results"]:
        res = STATE["eval_results"]["results"]
        rows = []
        for name, data in res.items():
            agg = data.get("aggregated", {})
            rows.append({
                "Scenario": name.replace("_", " ").title(),
                "Accuracy": f"{agg.get('avg_accuracy', 0):.4f}",
                "Energy Saving %": f"{agg.get('avg_energy_saving_percent', 0):.2f}",
                "False Activation Rate": f"{agg.get('avg_false_activation_rate', 0):.4f}",
            })
        st.dataframe(rows, use_container_width=True)

        try:
            import plotly.graph_objects as go
            names = [r["Scenario"] for r in rows]
            accs = [float(r["Accuracy"]) for r in rows]
            fig = go.Figure(go.Bar(x=names, y=accs, marker_color="#19E3C4"))
            fig.update_layout(
                title="Decision Accuracy by Scenario",
                yaxis_title="Accuracy", height=320,
                plot_bgcolor="#111B30", paper_bgcolor="#111B30",
                font=dict(color="#E8F0FF"),
            )
            st.plotly_chart(fig, use_container_width=True)
        except Exception:
            pass

        if st.button("Download test report (PDF)"):
            with st.spinner("Generating PDF..."):
                generate_all_reports(res, {})
                st.success("Report ready at docs/Test_Report.pdf")
    else:
        st.info("Run an evaluation to see per-scenario results.")


# =============================================================================
# Footer
# =============================================================================
st.markdown(
    '<hr style="border-color:#1E2D4A;margin-top:1.5rem;margin-bottom:0.8rem;">'
    '<p style="color:#8FA3C4;font-size:0.85rem;text-align:center;">'
    'Smart Classroom Controller v1.0 — Streamlit · Plotly · Python</p>',
    unsafe_allow_html=True,
)