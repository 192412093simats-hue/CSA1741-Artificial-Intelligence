"""Generate architecture diagram."""

import matplotlib.pyplot as plt
import matplotlib.patches as patches

fig, ax = plt.subplots(figsize=(12, 8))

# Layer colors
colors = {
    'ui': '#e3f2fd',
    'controller': '#e8f5e9',
    'simulator': '#fff3e0',
    'config': '#f3e5f5',
    'evaluation': '#fce4ec',
    'database': '#e0e0e0'
}

# Define box style
box_style = dict(boxstyle="round,pad=0.5", facecolor="lightblue", edgecolor="navy", linewidth=2)

# Draw layers
layers = [
    ("User Interface", 9.5, 0.8, colors['ui'], '#1976d2', '#0d47a1'),
    ("Controller Module", 7.0, 2.2, colors['controller'], '#388e3c', '#1b5e20'),
    ("IoT Simulator", 4.5, 2.2, colors['simulator'], '#f57c00', '#e65100'),
    ("Configuration", 2.0, 2.2, colors['config'], '#7b1fa2', '#4a148c'),
    ("Evaluation", 2.0, 0.0, colors['evaluation'], '#c2185b', '#880e4f'),
]

for label, y, width, color, edge, text_color in layers:
    ax.add_patch(patches.FancyBboxPatch((0, y), 10, width, boxstyle="round,pad=0.5", facecolor=color, edgecolor=edge, linewidth=2))
    ax.text(5, y + width/2, label, ha='center', va='center', fontsize=14, fontweight='bold', color=text_color)

# Internal boxes for Controller
controller_boxes = [
    ("Rule Engine", 7, 7),
    ("Agent", 7, 5),
    ("Filters", 7, 3),
]

for label, x, y in controller_boxes:
    ax.add_patch(patches.FancyBboxPatch((x-1, y), 1.5, 0.8, boxstyle="round,pad=0.3", facecolor='white', edgecolor='#388e3c', linewidth=1.5))
    ax.text(x, y + 0.4, label, ha='center', va='center', fontsize=9, color='#1b5e20')

# Internal boxes for Simulator
sim_boxes = [
    ("Sensors", 4, 7),
    ("Devices", 4, 5),
    ("Scenarios", 4, 3),
]

for label, x, y in sim_boxes:
    ax.add_patch(patches.FancyBboxPatch((x-1, y), 1.5, 0.8, boxstyle="round,pad=0.3", facecolor='white', edgecolor='#f57c00', linewidth=1.5))
    ax.text(x, y + 0.4, label, ha='center', va='center', fontsize=9, color='#e65100')

# Arrows
ax.annotate('', xy=(5, 7.3), xytext=(5, 8.4), arrowprops=dict(arrowstyle='->', lw=2, color='#666'))
ax.annotate('', xy=(5, 4.6), xytext=(5, 6.8), arrowprops=dict(arrowstyle='->', lw=2, color='#666'))
ax.annotate('', xy=(1.2, 2.6), xytext=(5, 6.8), arrowprops=dict(arrowstyle='->', lw=2, color='#666'))
ax.annotate('', xy=(1.2, 0.4), xytext=(5, 6.8), arrowprops=dict(arrowstyle='->', lw=2, color='#666'))

# Title
plt.text(5, 10.5, 'Smart Classroom Controller - System Architecture', ha='center', va='center', fontsize=18, fontweight='bold', color='#212121')

# Labels
plt.text(2, 0.2, 'Metrics\\nReporting', ha='center', va='center', fontsize=9, color='#880e4f')

ax.set_xlim(-0.5, 10.5)
ax.set_ylim(-0.5, 11)
ax.axis('off')

plt.tight_layout()
plt.savefig('docs/architecture_diagram.png', dpi=150, bbox_inches='tight')
print("Architecture diagram saved to docs/architecture_diagram.png")