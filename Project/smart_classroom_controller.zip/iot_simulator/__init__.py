"""IoT simulator package for the Smart Classroom Controller."""

from .classroom import Classroom, Zone, SensorReading
from .sensors import SensorSimulator, SensorConfig, apply_sensor_faults, generate_ground_truth_readings
from .scenarios import ScenarioManager, parse_time, EMPTY, ARRIVAL, LECTURE, BREAK, DEPARTURE

__all__ = [
    "Classroom",
    "Zone",
    "SensorReading",
    "SensorSimulator",
    "SensorConfig",
    "apply_sensor_faults",
    "generate_ground_truth_readings",
    "ScenarioManager",
    "parse_time",
    "EMPTY",
    "ARRIVAL",
    "LECTURE",
    "BREAK",
    "DEPARTURE",
]
