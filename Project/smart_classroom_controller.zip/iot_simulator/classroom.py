"""Classroom simulation with zones, sensors, devices, and ground truth."""

import random
import numpy as np
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
from datetime import datetime, timedelta
import yaml

@dataclass
class Zone:
    """Represents a zone within the classroom."""
    id: str
    name: str
    bounds: Dict[str, float]  # {'x': x, 'y': y, 'width': w, 'height': h}

    @property
    def center(self) -> Dict[str, float]:
        return {
            'x': self.bounds['x'] + self.bounds['width'] / 2,
            'y': self.bounds['y'] + self.bounds['height'] / 2
        }

@dataclass
class SensorReading:
    """A single sensor reading at a specific timestamp."""
    timestamp: datetime
    occupancy: Optional[float]  # people count
    lux: Optional[float]        # ambient light in lux
    temperature: Optional[float]  # degC
    humidity: Optional[float]     # % RH
    co2: Optional[float]          # ppm
    zone: str
    is_noise: bool = False
    is_spike: bool = False
    is_dropped: bool = False

    def copy(self) -> "SensorReading":
        return SensorReading(
            timestamp=self.timestamp,
            occupancy=self.occupancy,
            lux=self.lux,
            temperature=self.temperature,
            humidity=self.humidity,
            co2=self.co2,
            zone=self.zone,
            is_noise=self.is_noise,
            is_spike=self.is_spike,
            is_dropped=self.is_dropped
        )


class Classroom:
    """Main classroom simulator managing zones, sensors, devices, and evaluation."""

    def __init__(self, config_file: str = "config/scenarios.yaml"):
        # Load configuration
        with open(config_file, 'r') as f:
            self.config = yaml.safe_load(f)

        # Load scenarios manager for schedule-based occupancy
        from .scenarios import ScenarioManager
        from .sensors import SensorSimulator, SensorConfig
        self.scenario_manager = ScenarioManager(config_file)

        # Default zones
        self.zones = ["front", "middle", "back"]
        self.zone_objects = {
            "front": Zone("front", "Front", {"x": 0, "y": 0, "width": 40, "height": 30}),
            "middle": Zone("middle", "Middle", {"x": 40, "y": 0, "width": 40, "height": 30}),
            "back": Zone("back", "Back", {"x": 80, "y": 0, "width": 40, "height": 30})
        }

        # Sensor simulator (with fault injection)
        defaults = self.config.get('defaults', {})
        base_noise = 1.0
        if defaults.get('noise_level', 1.0) > 0:
            base_noise = defaults.get('noise_level', 1.0)

        base_fault_prob = 0.01
        if defaults.get('fault_probability', 0.01) > 0:
            base_fault_prob = defaults.get('fault_probability', 0.01)

        from .sensors import SensorConfig
        default_config = SensorConfig(
            gaussian_noise_std=0.5 * base_noise,
            dropout_probability=min(0.3, base_fault_prob),
            spike_probability=min(0.05, base_fault_prob * 1.5),
            spike_magnitude=10.0,
            drift_rate=0.02,
        )

        self.sensor_sim = SensorSimulator(default_config)

        # Devices
        self.devices: List = []
        for zone_id in self.zones:
            from .devices import LightDevice, FanDevice
            self.devices.append(LightDevice(f"LIGHT-{zone_id}", zone_id, power_rating_watts=60.0))
            self.devices.append(FanDevice(f"FAN-{zone_id}", zone_id, power_rating_watts=30.0))

        # Simulation state
        self.current_time = datetime.now()
        self.readings: List[SensorReading] = []
        self.ground_truth: Dict[str, List[SensorReading]] = {}
        self.paused = False
        self.speed = 1.0
        self.seed = defaults.get('seed', 42)
        self.current_scenario = "normal_day"

        # Config values for controller
        self.load_thresholds()

    def load_thresholds(self) -> dict:
        """Load threshold configuration from thresholds.yaml."""
        with open('config/thresholds.yaml', 'r') as f:
            self.threshold_config = yaml.safe_load(f)
        return self.threshold_config

    def reset(self) -> None:
        """Reset simulation state."""
        self.sensor_sim.reset_drift()
        self.current_time = datetime.now()
        self.readings = []
        self.ground_truth = {}
        self.paused = False

        # Reset devices to default state
        for dev in self.devices:
            dev.state = dev._get_default_state()
            dev.history = []

    def set_scenario(self, name: str) -> None:
        """Set active scenario name."""
        if name in self.scenario_manager.get_scenarios_list():
            self.current_scenario = name
            self.sensor_sim.reset_drift()

    def toggle_pause(self) -> None:
        """Toggle pause state."""
        self.paused = not self.paused

    def set_speed(self, speed: float) -> None:
        """Set simulation speed (multiplier on time)."""
        self.speed = max(0.1, min(speed, 100.0))

    def generate_reading(self, zone: str, timestamp: datetime, is_ground_truth: bool = False) -> SensorReading:
        """Generate a single sensor reading for a zone at a specific timestamp."""
        # Get base values
        occupancy = self.scenario_manager.get_occupancy_at_time(
            self.current_scenario, timestamp)

        # Lux: daylight curve based on time of day
        hour_frac = (timestamp.hour + timestamp.minute / 60.0) / 24.0
        # Daylight: peaks around noon, low at night
        lux_base = 300 + 700 * max(0, min(1, 1 - abs((hour_frac - 0.5) / 0.5)))
        # Add time-of-day variation (e.g., buildings get brighter late morning)
        hour_factor = max(0.3, 1 - abs(hour_frac - 0.3) * 2)
        lux = lux_base * hour_factor

        temp = self._get_base_temp(timestamp)
        humidity = self._get_base_humidity(timestamp)
        co2 = self._get_base_co2(occupancy, timestamp)

        # Store base values before applying faults
        base_values = {
            'occupancy': occupancy,
            'lux': lux,
            'temperature': temp,
            'humidity': humidity,
            'co2': co2
        }

        # Build SensorReading with base values first
        base_reading = SensorReading(
            timestamp=timestamp,
            occupancy=occupancy,
            lux=lux,
            temperature=temp,
            humidity=humidity,
            co2=co2,
            zone=zone
        )

        # Apply faults only for non-ground-truth readings
        if is_ground_truth:
            # Ground truth: no faults applied
            reading = base_reading
        else:
            from .sensors import apply_sensor_faults
            reading = apply_sensor_faults(base_reading, self.sensor_sim, seed=self.seed + hash(timestamp.isoformat()) % 10000)

        return reading

    def _get_base_temp(self, timestamp: datetime) -> float:
        scenario = self.scenario_manager.get_scenario(self.current_scenario)
        base_temp = scenario.get('base_temp', 25.0)
        # Add small evening cooling effect
        if (timestamp.hour < 8 or timestamp.hour > 19):
            base_temp *= 0.95
        return base_temp

    def _get_base_humidity(self, timestamp: datetime) -> float:
        scenario = self.scenario_manager.get_scenario(self.current_scenario)
        base_humidity = scenario.get('base_humidity', 55.0)
        # Morning humidity tends higher
        if 7 <= timestamp.hour <= 9:
            base_humidity += 2
        return base_humidity

    def _get_base_co2(self, occupancy: float, timestamp: datetime) -> float:
        # CO2 rises with occupancy and may be higher during lectures
        co2_base = 600.0
        if occupancy > 0:
            co2_base += occupancy * 15.0
        # Lecture rooms may have more CO2
        if 9 <= timestamp.hour <= 12 or 14 <= timestamp.hour <= 17:
            co2_base += 200.0
        return co2_base

    def step(self, seconds: int = 60) -> List[Tuple[SensorReading, List]]:
        """Advance simulation by the given number of seconds (in sim-time).

        Returns list of (sensor_reading, device_states_changed) tuples.
        """
        if self.paused:
            return []

        # Advance time by seconds / speed
        advances = seconds / self.speed if self.speed > 0 else seconds
        num_steps = max(1, int(round(advances / 60.0)))  # 60 seconds per minute

        changes = []
        for _ in range(num_steps):
            new_time = self.current_time + timedelta(seconds=60.0)

            # Generate readings for each zone (both noisy and ground truth)
            noisy_readings = []
            gt_readings = []
            for zone_id in self.zones:
                noisy = self.generate_reading(zone_id, new_time, is_ground_truth=False)
                noisy_readings.append(noisy)
                gt_reading = self.generate_reading(zone_id, new_time, is_ground_truth=True)
                gt_readings.append(gt_reading)

            self.current_time = new_time
            self.readings.extend(noisy_readings)

            # Compute ground truth state (which lights should be on)
            for i, gt_reading in enumerate(gt_readings):
                zone_id = self.zones[i]
                gt_lights_on = (gt_reading.occupancy is not None and gt_reading.occupancy > 0) and \
                               (gt_reading.lux is not None and gt_reading.lux < self.threshold_config.get('lights', {}).get('lux_low', 300))
                # Fan speed based on temp and occupancy
                if gt_reading.temperature is not None and gt_reading.occupancy is not None:
                    fan_target = max(0, min(3, int(gt_reading.temperature - 24)))
                else:
                    fan_target = 0
                self.ground_truth[zone_id] = gt_readings

            # For device simulation, apply the noisy readings
            for dev in self.devices:
                pass  # Device logic handled by controller

            changes.append((noisy_readings, gt_readings))

        return changes

    def save_results(self) -> dict:
        """Save results to a dictionary for evaluation."""
        return {
            'readings': [r.__dict__ for r in self.readings],
            'ground_truth': self.ground_truth,
            'devices': [d.to_dict() for d in self.devices],
            'scenario': self.current_scenario
        }

    def get_all_readings(self) -> List[SensorReading]:
        """Get all current readings."""
        return self.readings

    def get_device_history(self, device_id: str) -> List:
        """Get device history for a specific device."""
        for dev in self.devices:
            if dev.device_id == device_id:
                return dev.history
        return []

    def get_initial_state(self) -> dict:
        """Get initial system state for comparison."""
        from .agent import ControllerAgent
        state = {
            'time': self.current_time.isoformat(),
            'readings': [r.__dict__ for r in self.readings[:1]],
            'devices': [d.to_dict() for d in self.devices],
            'scenario': self.current_scenario,
            'thresholds': self.threshold_config
        }
        return state