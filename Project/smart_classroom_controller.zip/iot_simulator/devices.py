"""Virtual devices for the Smart Classroom Controller."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional
from datetime import datetime

@dataclass
class DeviceState:
    """State of a device at a specific time."""
    timestamp: datetime
    device_id: str
    zone: str
    device_type: str  # 'light', 'fan', 'ac'
    state: Dict[str, object]  # device-specific state
    power_watts: float = 0.0  # Power consumption in watts

    def to_dict(self) -> dict:
        """Convert DeviceState to dictionary."""
        return {
            'timestamp': self.timestamp.isoformat(),
            'device_id': self.device_id,
            'zone': self.zone,
            'device_type': self.device_type,
            'state': self.state,
            'power_watts': self.power_watts
        }

class Device:
    """Base class for all virtual devices."""
    def __init__(self, device_id: str, device_type: str, zone: str, power_rating_watts: float = 0.0):
        self.device_id = device_id
        self.device_type = device_type
        self.zone = zone
        self.power_rating_watts = power_rating_watts
        self.state = self._get_default_state()
        self.history: List[DeviceState] = []

    def _get_default_state(self) -> Dict[str, object]:
        """Get default state for device type."""
        if self.device_type == 'light':
            return {'on': False, 'brightness': 0}  # 0-100%
        elif self.device_type == 'fan':
            return {'on': False, 'speed': 0}  # 0-3
        elif self.device_type == 'ac':
            return {'on': False, 'temperature': 24}  # target temp in degC
        else:
            return {'on': False}

    def update(self, command: Dict[str, object]) -> None:
        """Apply a command to the device state."""
        if 'on' in command:
            self.state['on'] = bool(command['on'])
        if 'brightness' in command:
            self.state['brightness'] = max(0, min(100, int(command['brightness'])))
        if 'speed' in command:
            self.state['speed'] = max(0, min(3, int(command['speed'])))
        if 'temperature' in command:
            self.state['temperature'] = command['temperature']

    def get_power_watts(self) -> float:
        """Get current power consumption in watts."""
        if not self.state.get('on', False):
            return 0.0
        if self.device_type == 'light':
            return self.state.get('brightness', 0) / 100.0 * self.power_rating_watts
        elif self.device_type == 'fan':
            return (self.state.get('speed', 0) / 3.0) * self.power_rating_watts
        elif self.device_type == 'ac':
            return self.power_rating_watts
        return 0.0

    def log_state(self, timestamp: datetime) -> None:
        """Log device state at a specific timestamp."""
        self.history.append(DeviceState(
            timestamp=timestamp,
            device_id=self.device_id,
            zone=self.zone,
            device_type=self.device_type,
            state=self.state,
            power_watts=self.get_power_watts()
        ))

    def to_dict(self) -> dict:
        """Convert device to dictionary for serialization."""
        return {
            'device_id': self.device_id,
            'device_type': self.device_type,
            'zone': self.zone,
            'power_rating_watts': self.power_rating_watts,
            'state': self.state
        }

class LightDevice(Device):
    """A controllable light device."""
    def __init__(self, device_id: str, zone: str, power_rating_watts: float = 60.0):
        super().__init__(device_id, 'light', zone, power_rating_watts)

    def apply_rule(self, on: bool, brightness: float = None) -> None:
        """Apply a rule-based command."""
        if brightness is not None:
            self.state['on'] = on
            self.state['brightness'] = int(brightness)
        else:
            self.state['on'] = on
            if on and self.state.get('brightness', 0) == 0:
                self.state['brightness'] = 50  # Default brightness if turning on

    def to_dict(self) -> dict:
        return {
            'device_id': self.device_id,
            'device_type': self.device_type,
            'zone': self.zone,
            'power_rating_watts': self.power_rating_watts,
            'state': self.state
        }

class FanDevice(Device):
    """A controllable fan device."""
    def __init__(self, device_id: str, zone: str, power_rating_watts: float = 30.0):
        super().__init__(device_id, 'fan', zone, power_rating_watts)

    def to_dict(self) -> dict:
        return {
            'device_id': self.device_id,
            'device_type': self.device_type,
            'zone': self.zone,
            'power_rating_watts': self.power_rating_watts,
            'state': self.state
        }

class ACDevice(Device):
    """A controllable AC device."""
    def __init__(self, device_id: str, zone: str, power_rating_watts: float = 150.0):
        super().__init__(device_id, 'ac', zone, power_rating_watts)

    def to_dict(self) -> dict:
        return {
            'device_id': self.device_id,
            'device_type': self.device_type,
            'zone': self.zone,
            'power_rating_watts': self.power_rating_watts,
            'state': self.state
        }


def create_devices(cls) -> List[Device]:
    """Create default device set for a classroom."""
    devices = []
    for zone_id in cls.zones:
        devices.append(LightDevice(f"LIGHT-{zone_id}", zone_id, power_rating_watts=60.0))
        devices.append(FanDevice(f"FAN-{zone_id}", zone_id, power_rating_watts=30.0))
        # Optional AC per zone (can be disabled via config)
    return devices
