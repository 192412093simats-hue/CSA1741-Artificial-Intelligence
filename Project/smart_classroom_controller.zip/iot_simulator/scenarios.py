"""Scenario presets for the Smart Classroom Controller simulation."""

import yaml
from datetime import datetime
from typing import Dict, List, Optional

# Time of day categories
EMPTY = 'empty'
ARRIVAL = 'arrival'
LECTURE = 'lecture'
BREAK = 'break'
DEPARTURE = 'departure'

class ScenarioManager:
    """Manages scenario presets and schedule-based occupancy patterns."""

    def __init__(self, config_file: str = "config/scenarios.yaml"):
        with open(config_file, 'r') as f:
            self.config = yaml.safe_load(f)

    def get_scenario(self, name: str) -> Dict:
        """Get a scenario configuration by name."""
        return self.config.get('scenarios', {}).get(name, {})

    def get_default_config(self) -> Dict:
        """Get default simulation configuration."""
        return self.config.get('defaults', {})

    def get_occupancy_at_time(self, scenario_name: str, timestamp: datetime) -> float:
        """Get occupancy (people count) for a given timestamp based on the scenario schedule."""
        scenario = self.get_scenario(scenario_name)

        if not scenario.get('schedule'):
            # No schedule - use base_occupancy
            return scenario.get('base_occupancy', 0)

        # The schedule is a chronological list of periods; the period that
        # applies at `timestamp` is the LAST entry whose start <= now.
        # (The first entry whose [start, start+duration) window contains now
        # would be wrong: an "empty" entry lasts 24 h and swallows the day.)
        current_minutes = timestamp.hour * 60 + timestamp.minute
        matched_pattern = None
        matched_start = None
        for entry in scenario['schedule']:
            start_time_str, pattern = entry
            hour, minute = map(int, start_time_str.split(':'))
            entry_start = hour * 60 + minute
            if entry_start <= current_minutes:
                matched_pattern = pattern
                matched_start = entry_start

        if matched_pattern is None:
            return 0

        # Past the final scheduled period -> nobody in the room.
        if current_minutes >= matched_start + self._get_schedule_duration(matched_pattern):
            return 0

        if matched_pattern == EMPTY:
            return 0
        elif matched_pattern in ('arrival', 'departure'):
            return 1  # Simple approximation
        elif matched_pattern == 'break':
            return max(0, scenario.get('base_occupancy', 0) * 0.2)
        elif matched_pattern == 'lecture':
            return scenario.get('base_occupancy', 0)

        # Default to empty or base
        return 0

    def _get_schedule_duration(self, pattern: str) -> int:
        """Get duration in minutes for a pattern."""
        duration_map = {
            'empty': 24 * 60,  # Empty for the rest of the day
            'arrival': 60,     # Arrival period
            'departure': 60,   # Departure period
            'break': 60,       # Break period
            'lecture': 120,    # Lecture period (2 hours)
        }
        return duration_map.get(pattern, 120)

    def get_scenarios_list(self) -> List[str]:
        """Get list of available scenario names."""
        return list(self.config.get('scenarios', {}).keys())


def parse_time(time_str: str) -> int:
    """Parse time string like 'HH:MM' to minutes since midnight."""
    hour, minute = map(int, time_str.split(':'))
    return hour * 60 + minute
