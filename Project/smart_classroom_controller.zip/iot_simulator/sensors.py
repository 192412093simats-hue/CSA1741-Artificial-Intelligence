"""Sensor simulation with realistic noise, dropout, spike, and drift behavior."""

import random
import numpy as np
from datetime import datetime
from typing import List
from dataclasses import dataclass
from iot_simulator.classroom import SensorReading
from dataclasses import dataclass

@dataclass
class SensorConfig:
    """Configuration for sensor behavior."""
    # Noise parameters
    gaussian_noise_std: float = 1.0  # Standard deviation for Gaussian noise
    dropout_probability: float = 0.05  # Probability of sensor dropout per reading
    spike_probability: float = 0.03    # Probability of spike per reading
    spike_magnitude: float = 10.0      # Magnitude of spikes

    # Drift parameters
    drift_rate: float = 0.02  # Rate of drift per minute

    # Sensor ranges (valid values)
    occupancy_range: tuple = (0, 100)
    lux_range: tuple = (0, 2000)
    temperature_range: tuple = (15, 40)
    humidity_range: tuple = (20, 90)
    co2_range: tuple = (300, 2000)

    # Outlier thresholds (beyond which sensor reading is considered an outlier)
    occupancy_outlier_std: float = 3.0
    lux_outlier_std: float = 3.0
    temperature_outlier_std: float = 3.0
    humidity_outlier_std: float = 3.0
    co2_outlier_std: float = 3.0

    @classmethod
    def from_scenario(cls, scenario_name: str, scenario_config: dict) -> "SensorConfig":
        """Create SensorConfig from scenario configuration."""
        defaults = scenario_config.get('defaults', {})
        scenario = scenario_config['scenarios'].get(scenario_name, {})

        config = cls()

        # Apply scenario overrides
        if 'overrides' in scenario:
            for key, value in scenario['overrides'].items():
                if hasattr(config, key):
                    setattr(config, key, value)

        # Apply default values
        for key, value in defaults.items():
            if hasattr(config, key):
                setattr(config, key, value)

        # Apply scenario noise levels
        noise_level = scenario.get('noise_level', 1.0)
        fault_probability = scenario.get('fault_probability', 0.01)

        config.gaussian_noise_std = config.gaussian_noise_std * noise_level
        config.dropout_probability = min(0.5, fault_probability)
        config.spike_probability = min(0.2, fault_probability * 1.5)
        config.drift_rate = config.drift_rate * noise_level

        return config
class SensorSimulator:
    """Simulates sensor readings with realistic imperfections."""

    def __init__(self, config: SensorConfig):
        self.config = config
        self.last_drift = {
            'lux': 0,
            'temperature': 0,
            'humidity': 0,
            'co2': 0
        }

    def simulate_reading(self, sensor_type: str, base_value: float, timestamp: datetime,
                        sensor_history: List[SensorReading] = None) -> float:
        """Simulate a sensor reading with noise, dropout, spikes, and drift.

        Args:
            sensor_type: Type of sensor ('occupancy', 'lux', 'temperature', 'humidity', 'co2')
            base_value: The ideal/true value for this sensor
            timestamp: When this reading was taken
            sensor_history: Previous readings for drift calculation

        Returns:
            Simulated sensor reading with imperfections
        """
        # Apply random dropout
        if random.random() < self.config.dropout_probability:
            return None

        # Apply Gaussian noise
        noise = np.random.normal(0, self.config.gaussian_noise_std)
        reading = base_value + noise

        # Apply spikes (rare large deviations)
        if random.random() < self.config.spike_probability:
            reading += np.random.choice([-1, 1]) * self.config.spike_magnitude

        # Apply drift (gradual shift from true value)
        if sensor_type in self.last_drift:
            self.last_drift[sensor_type] += self.config.drift_rate * np.random.uniform(0.5, 1.5)
            reading += self.last_drift[sensor_type]

        # Ensure within valid range
        reading = self._clamp_to_range(reading, sensor_type)

        # Apply spike detection (based on deviation from expected variance)
        # This is a simplified check - in practice you'd look at recent history
        if self._is_outlier(sensor_type, reading):
            reading = base_value  # Reset to true value for outliers

        return reading

    def _clamp_to_range(self, value: float, sensor_type: str) -> float:
        """Clamp value to valid sensor range."""
        ranges = {
            'occupancy': self.config.occupancy_range,
            'lux': self.config.lux_range,
            'temperature': self.config.temperature_range,
            'humidity': self.config.humidity_range,
            'co2': self.config.co2_range
        }

        if sensor_type in ranges:
            low, high = ranges[sensor_type]
            return max(low, min(high, value))
        return value

    def _is_outlier(self, sensor_type: str, value: float) -> bool:
        """Check if a reading is an outlier based on typical variance."""
        # Simple outlier detection based on standard deviation
        # In practice you'd use more sophisticated methods
        thresholds = {
            'occupancy': self.config.occupancy_outlier_std,
            'lux': self.config.lux_outlier_std,
            'temperature': self.config.temperature_outlier_std,
            'humidity': self.config.humidity_outlier_std,
            'co2': self.config.co2_outlier_std
        }

        if sensor_type not in thresholds:
            return False

        # We don't have easy access to mean/std here, so this is simplified
        # In practice, you'd maintain running statistics
        return False

    def reset_drift(self) -> None:
        """Reset drift to zero."""
        for key in self.last_drift:
            self.last_drift[key] = 0


def apply_sensor_faults(reading: SensorReading, sensor_simulator: SensorSimulator, seed: int = None) -> SensorReading:
    """Apply realistic faults (noise, spikes, dropouts) to a sensor reading."""
    if seed is not None:
        random.seed(seed)
        np.random.seed(seed)

    # Store original values
    original_values = {
        'occupancy': reading.occupancy,
        'lux': reading.lux,
        'temperature': reading.temperature,
        'humidity': reading.humidity,
        'co2': reading.co2
    }

    # Apply faults to each sensor
    if sensor_simulator.simulate_reading('occupancy', original_values['occupancy'], reading.timestamp) is None:
        reading.occupancy = None
        reading.is_dropped = True

    # For continuous sensors, always generate a reading but with faults
    reading.lux = sensor_simulator.simulate_reading('lux', original_values['lux'], reading.timestamp)
    reading.temperature = sensor_simulator.simulate_reading('temperature', original_values['temperature'], reading.timestamp)
    reading.humidity = sensor_simulator.simulate_reading('humidity', original_values['humidity'], reading.timestamp)
    reading.co2 = sensor_simulator.simulate_reading('co2', original_values['co2'], reading.timestamp)

    # Detect spikes (large deviations from expected)
    for sensor_type, value in original_values.items():
        if value is not None and getattr(reading, sensor_type) is not None:
            if abs(getattr(reading, sensor_type) - value) > sensor_simulator.config.spike_magnitude:
                setattr(reading, f'is_spike_{sensor_type}', True)

    return reading


def generate_ground_truth_readings(classroom: "Classroom", seed: int = None) -> List[SensorReading]:
    """Generate ground truth readings (noise-free) for evaluation."""
    if seed is not None:
        random.seed(seed)
        np.random.seed(seed)

    all_readings = []
    timestamp = datetime.now()

    # Generate readings for each zone
    for zone_id in classroom.zones:
        reading = classroom.get_sensor_reading(zone_id, timestamp)
        all_readings.append(reading)

    return all_readings