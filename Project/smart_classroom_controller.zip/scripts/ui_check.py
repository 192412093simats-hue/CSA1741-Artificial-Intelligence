"""Playwright acceptance checks for the Smart Classroom Controller UI.

Verifies, in a real Chromium browser at 1920x1080:
  1. Manual: set lux slider low, click seat F1 -> Occupancy 1 + Front L1 ON;
     click again -> Occupancy 0 + Front L1 OFF.
  2. Manual: Fill all seats -> Occupancy 48, lights ON in all 3 zones.
  3. Auto: seat buttons disabled; Start -> KPI values change, no exception.

Saves docs/screenshots/manual_one_seat.png, manual_full.png, auto_running.png.
FAILS (exit 1) on any assertion error or any div[data-testid="stException"].

Run:  .venv\Scripts\python.exe scripts/ui_check.py
"""
import asyncio
import sys
import time
from pathlib import Path

from playwright.async_api import async_playwright

BASE = "http://localhost:8501"
SHOTS = Path("docs/screenshots")


class Fail(Exception):
    pass


def clean(s: str) -> str:
    """Strip emoji/non-ASCII so the Windows cp1252 console can print it."""
    return "".join(ch for ch in s if ch.isascii() or ch.isspace()).strip()


async def no_exception(page, where: str) -> None:
    if await page.locator('div[data-testid="stException"]').count():
        raise Fail(f"{where}: stException appeared on page")


async def shoot(page, name: str) -> None:
    """Move the pointer off widgets, then capture the WHOLE page.

    Streamlit scrolls an inner section, so Playwright's full_page cannot
    extend past the viewport; sizing the viewport to the content height
    captures the entire dashboard in one image.
    """
    await page.mouse.move(2, 2)
    await page.wait_for_timeout(300)
    h = await page.evaluate(
        "() => document.querySelector('section.main').scrollHeight"
    )
    await page.set_viewport_size({"width": 1920, "height": max(1080, min(h + 8, 4000))})
    await page.wait_for_timeout(400)
    await page.screenshot(path=str(SHOTS / name), full_page=True)
    print(f"    saved docs/screenshots/{name}")


async def kpi(page, idx: int) -> str:
    return (await page.locator(".kpi-value").nth(idx).inner_text()).strip()


async def wait_kpi(page, idx: int, expected: str, timeout_ms: int = 8000) -> str:
    deadline = time.time() + timeout_ms / 1000
    txt = ""
    while time.time() < deadline:
        txt = await kpi(page, idx)
        if expected in txt:
            return txt
        await page.wait_for_timeout(200)
    raise Fail(f"KPI[{idx}] never contained {expected!r}; last value {txt!r}")


def card(page, zone: str):
    return page.locator("div.st-emotion-cache-tg52rz").filter(has_text=zone.capitalize()).first


async def light_state(page, zone: str, n: int) -> str:
    txt = await card(page, zone).locator(".light-indicator").nth(n - 1).inner_text()
    return clean(txt.replace("\n", " "))


async def set_lux_slider(page, fraction: float) -> None:
    """Click the lux slider rail at `fraction` of its width (0..1).

    Waits until the server has APPLIED the value, not just printed it: with
    all seats empty the Light Level KPI equals outside lux exactly (lights off),
    so the seat click can no longer race the slider's on_change rerun.
    """
    slider = page.locator('div[data-testid="stSlider"]').first
    box = await slider.bounding_box()
    await page.mouse.click(box["x"] + box["width"] * fraction, box["y"] + box["height"] / 2)
    # wait until the printed value is a plausible low number
    value = None
    deadline = time.time() + 5
    while time.time() < deadline:
        label = await slider.inner_text()
        lines = [l.strip() for l in label.split("\n") if l.strip()]
        if len(lines) >= 4 and lines[1].isdigit() and int(lines[1]) < 300:
            value = int(lines[1])
            break
        await page.wait_for_timeout(200)
    if value is None:
        raise Fail(f"lux slider did not move low; label now: {label!r}")
    # server-side application: Light Level KPI == outside lux while unlit
    deadline = time.time() + 8
    while time.time() < deadline:
        lux_txt = (await kpi(page, 1)).strip()
        if lux_txt.isdigit() and int(lux_txt) == value:
            return
        await page.wait_for_timeout(200)
    raise Fail(f"Light Level KPI never reached outside lux {value}; last={lux_txt!r}")


async def main() -> int:
    SHOTS.mkdir(parents=True, exist_ok=True)
    failures = []

    async with async_playwright() as pw:
        # headless: headed Chromium crashes on this VM once the Auto rerun
        # loop starts; headless renders the same pixels for screenshots.
        browser = await pw.chromium.launch(headless=True)
        page = await browser.new_page(viewport={"width": 1920, "height": 1080})
        await page.goto(BASE)
        await page.wait_for_selector(".kpi-value", timeout=20000)
        await page.wait_for_timeout(1500)

        # ── 1. Manual: click seat F1 on/off -------------------------------
        print("[1] Manual: low lux + click seat F1 ...")
        await page.get_by_text("Manual - click the seats", exact=True).click()
        await page.wait_for_timeout(500)
        await set_lux_slider(page, 0.10)  # ~100 lux -> dark room
        seat = card(page, "front").locator(".stTooltipHoverTarget button").first
        await seat.click()
        await wait_kpi(page, 0, "1")
        state = await light_state(page, "front", 1)
        print(f"    occupancy={await kpi(page, 0)}, front L1 = {state!r}")
        if "ON" not in state:
            failures.append("seat F1 click did not turn Front L1 ON")
        await no_exception(page, "manual seat click")
        await shoot(page, "manual_one_seat.png")

        await seat.click()
        await wait_kpi(page, 0, "0")
        state = await light_state(page, "front", 1)
        print(f"    re-click: occupancy={await kpi(page, 0)}, front L1 = {state!r}")
        if "OFF" not in state:
            failures.append("seat F1 re-click did not turn Front L1 OFF")

        # ── 2. Fill all seats -> 48 ---------------------------------------
        print("[2] Manual: Fill all seats ...")
        await page.get_by_role("button", name="Fill all seats").click()
        await wait_kpi(page, 0, "48")
        for zone in ("front", "middle", "back"):
            state = await light_state(page, zone, 1)
            print(f"    {zone}: {state}")
            if "ON" not in state:
                failures.append(f"Fill all seats: {zone} light not ON")
        await no_exception(page, "fill all seats")
        await shoot(page, "manual_full.png")

        # ── 3. Auto: seats disabled, start, values change -----------------
        print("[3] Auto mode ...")
        await page.get_by_text("Auto - run simulation", exact=True).click()
        await page.wait_for_timeout(500)
        if not await card(page, "front").locator(".stTooltipHoverTarget button").first.is_disabled():
            failures.append("Auto mode: seat buttons are not disabled")
        await page.locator('div[data-testid="stSelectbox"]').click()
        await page.get_by_role("option", name="Normal Day").click()
        await page.wait_for_timeout(300)

        before = [await kpi(page, i) for i in range(4)]
        await page.get_by_role("button", name="▶ Start").click()
        # wait until occupancy is non-zero (scenario ramp-up) or 20s pass
        occ_deadline = time.time() + 20
        while time.time() < occ_deadline:
            if (await kpi(page, 0)) != "0":
                break
            await page.wait_for_timeout(300)
        print(f"    occupancy after start: {await kpi(page, 0)}")
        changed = False
        deadline = time.time() + 15
        while time.time() < deadline:
            await page.wait_for_timeout(500)
            now = [await kpi(page, i) for i in range(4)]
            if now != before:
                changed = True
                print(f"    KPIs changed: {before} -> {now}")
                break
        if not changed:
            failures.append(f"Auto: KPIs did not change in 15 s ({before})")
        await no_exception(page, "auto running")
        await shoot(page, "auto_running.png")
        await page.get_by_role("button", name="⏸ Pause").click()
        await page.wait_for_timeout(500)
        await no_exception(page, "auto pause")

        await browser.close()

    print()
    if failures:
        print("RESULT: FAIL")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("RESULT: PASS — all acceptance checks green, no stException anywhere.")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
