"""Run full evaluation across all 6 scenarios and print metrics."""
import sys
sys.path.insert(0, "D:\\Projects\\smart_classroom_controller")
from evaluation.run_evaluation import run_full_evaluation, save_results_json

results = run_full_evaluation(num_simulations_per_scenario=5, simulation_seconds=480, seed=42)
save_results_json(results)
print("Evaluation complete!")
print()
for scenario, data in results["results"].items():
    agg = data["aggregated"]
    print(scenario + ":")
    print("  Accuracy:           {:.4f}".format(agg["avg_accuracy"]))
    print("  Energy Saving:      {:.2f}%".format(agg["avg_energy_saving_percent"]))
    print("  False Act Rate:     {:.4f}".format(agg["avg_false_activation_rate"]))
    print("  Fan Accuracy:       {:.4f}".format(agg["avg_fan_accuracy"]))
print()
print("Saved to results/evaluation_results.json")