"""Regenerate test reports (MD + PDF) from the latest evaluation results."""
import json
import sys
sys.path.insert(0, "D:\\Projects\\smart_classroom_controller")
from evaluation.report_generator import generate_all_reports

with open("results/evaluation_results.json") as f:
    results = json.load(f)

# Compute average energy saving across all scenarios for controller_metrics
scenario_results = results["results"]
avg_energy_saving = sum(
    data["aggregated"].get("avg_energy_saving_percent", 0)
    for data in scenario_results.values()
) / len(scenario_results) if scenario_results else 0
controller_metrics = {"energy_saving_percent": avg_energy_saving}

# Use the three accepted screenshots for the report
screenshot_paths = [
    "docs/screenshots/manual_one_seat.png",
    "docs/screenshots/manual_full.png",
    "docs/screenshots/auto_running.png",
]

generate_all_reports(scenario_results, controller_metrics, screenshot_paths=screenshot_paths)
print("Reports regenerated in docs/")