"""Generate test report in Markdown and PDF format."""
import os
import json
from datetime import datetime
from typing import Dict, List, Optional
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib import colors


def generate_markdown_report(
    evaluation_results: Dict,
    controller_metrics: Dict,
    output_path: str = "docs/Test_Report.md",
    pytest_results: str = "",
    screenshot_paths: List[str] = None,
) -> None:
    """Generate Markdown test report."""
    lines = []
    lines.append("# AI-Powered Smart Classroom Controller - Test Report")
    lines.append("")
    lines.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append("")
    lines.append("**Project:** AI-Powered Smart Classroom Controller")
    lines.append("**Version:** 1.0.0")
    lines.append("")
    lines.append("## 1. Abstract and Objectives")
    lines.append("")
    lines.append("This document describes the AI-Powered Smart Classroom Controller, a prototype that recommends or simulates ")
    lines.append("lighting and fan control in a classroom based on occupancy and environmental inputs.")
    lines.append("")
    lines.append("### Objectives")
    lines.append("")
    lines.append("1. Build an end-to-end prototype with simulated IoT sensors and virtual devices.")
    lines.append("2. Implement transparent, threshold-based, rule-based control with hysteresis and dwell time.")
    lines.append("3. Evaluate decision accuracy, response latency, energy savings, and false activation rate.")
    lines.append("4. Generate interactive Streamlit dashboard and automated test reports.")
    lines.append("")
    lines.append("## 2. System Architecture")
    lines.append("")
    lines.append("The system consists of: IoT Sensor Simulation Module, Control Logic Module, Evaluation Module, and Streamlit App.")
    lines.append("")
    lines.append("## 3. Module Descriptions")
    lines.append("")
    lines.append("### Module 1: Sensor/Input Simulation")
    lines.append("")
    lines.append("The IoT simulator generates occupancy, ambient light, temperature, humidity, and CO2 readings with ")
    lines.append("configurable noise, dropouts, spikes, and drift. Ground truth values are computed for validation.")
    lines.append("")
    lines.append("### Module 2: Decision Rules and Control")
    lines.append("")
    lines.append("The controller applies threshold-based rules with hysteresis and minimum dwell time to control lights and fans.")
    lines.append("")
    lines.append("### Module 3: System Testing and Evaluation")
    lines.append("")
    lines.append("The evaluation harness runs seeded simulations across multiple scenarios and computes accuracy, latency, energy savings, and false activation rates.")
    lines.append("")
    lines.append("## 4. Results")
    lines.append("")
    lines.append("### 4.1 Decision Accuracy")
    # evaluation_results is a dict with scenario keys (normal_day, exam_day, etc.)
    # each has "aggregated" with the metrics
    for scenario, results_data in evaluation_results.items():
        agg = results_data.get("aggregated", {})
        lines.append(f"### Scenario: {scenario}")
        lines.append("")
        lines.append(f"- Average Decision Accuracy: {agg.get('avg_accuracy', 0):.4f}")
        lines.append(f"- Average Precision: {agg.get('avg_precision', 0):.4f}")
        lines.append(f"- Average Recall: {agg.get('avg_recall', 0):.4f}")
        lines.append(f"- Average F1 Score: {agg.get('avg_f1', 0):.4f}")
        lines.append(f"- Average Fan Accuracy: {agg.get('avg_fan_accuracy', 0):.4f}")
        lines.append(f"- Average Fan Precision: {agg.get('avg_fan_precision', 0):.4f}")
        lines.append(f"- Average Fan Recall: {agg.get('avg_fan_recall', 0):.4f}")
        lines.append(f"- Average Fan F1: {agg.get('avg_fan_f1', 0):.4f}")
        lines.append(f"- Average Energy Saving: {agg.get('avg_energy_saving_percent', 0):.2f}%")
        lines.append(f"- Average False Activation Rate: {agg.get('avg_false_activation_rate', 0):.4f}")
        lines.append("")
    lines.append("### 4.2 Energy Savings")
    lines.append("")
    lines.append(f"Energy savings achieved: {controller_metrics.get('energy_saving_percent', 0):.2f}%")
    lines.append("")
    lines.append("## 5. User Interface")
    lines.append("")
    lines.append("The Streamlit dashboard is a single page: a sidebar mode switcher plus a header, KPI row, classroom hero, "
    "decision log + energy cards, and a bottom metrics strip; tabs split it into Live Dashboard and Evaluation.")
    lines.append("")
    lines.append("### Sidebar — Mode switcher")
    lines.append("Mode radio with exactly two options: \"Manual - click the seats\" and \"Auto - run simulation\".")
    lines.append("In Manual mode the sidebar shows an Outside light (lux) slider (0-1000, default 600), a Room temperature "
    "slider (20-40 °C, default 28), and \"Fill all seats\" / \"Clear all seats\" buttons. No speed slider, thresholds, "
    "noise, fault toggles, or seed controls.")
    lines.append("In Auto mode the sidebar shows a Scenario dropdown (Normal Day, Exam Day, Hot Afternoon, Empty Weekend) "
    "plus Start / Pause / Reset buttons.")
    lines.append("")
    lines.append("### Header")
    lines.append("Graduation-cap icon with title \"Smart Classroom Controller\" and subtitle \"AI-Powered Rule-Based Lighting & Fan Control\". "
    "Right side shows a Mode chip (MANUAL / AUTO).")
    lines.append("")
    lines.append("### KPI Row")
    lines.append("Four cards: Occupancy (people), Light Level (lux) = outside lux + 150 per lit zone, Temperature (°C), CO₂ (ppm) = 400 + 15 × occupancy.")
    lines.append("")
    lines.append("### Classroom hero")
    lines.append("Whiteboard / Teacher Desk bar, then three zone cards (Front / Middle / Back), each with a teal dashed border, "
    "zone pill, L1/L2 light indicators (ON/OFF), a fan indicator (Speed 0..3), and a 2×8 grid of real clickable seat buttons "
    "(16 per zone, 48 total). Stable keys seat_{zone}_{index}. Seats toggle occupancy instantly in Manual mode and are disabled in Auto mode, "
    "where they mirror simulator occupancy.")
    lines.append("")
    lines.append("### Outside light card")
    lines.append("Sun icon card showing outside lux plus a legend card (ON / OFF / Dimmed).")
    lines.append("")
    lines.append("### Decision Log")
    lines.append("Last 5 decisions, newest first, showing time, action, and reason with teal dots.")
    lines.append("")
    lines.append("### Energy card")
    lines.append("Manual mode: \"X% less power right now\" with controller vs baseline watts. Auto mode: baseline vs smart kWh with percentage saved bar.")
    lines.append("")
    lines.append("### Bottom strip")
    lines.append("Three metric cards via evaluation/metrics.py: Decision Accuracy, Response Latency (\"--\" in Manual mode), False Activation Rate.")
    lines.append("")
    lines.append("### Evaluation Tab")
    lines.append("\"Run evaluation\" button runs the batch harness across the selected scenarios and shows a per-scenario results "
    "table plus a Decision Accuracy bar chart. \"Download test report (PDF)\" button serves docs/Test_Report.pdf.")
    lines.append("")
    lines.append("## 6. Limitations and Future Work")
    lines.append("")
    lines.append("This prototype uses simulated sensors and devices. Real IoT hardware integration is future work.")
    lines.append("")
    if screenshot_paths:
        lines.append("## 7. Dashboard Screenshots")
        lines.append("")
        for sp in screenshot_paths:
            name = os.path.basename(sp)
            lines.append(f"![{name}]({sp})")
            lines.append("")
    lines.append("## 8. Test Cases (pytest Results)")
    lines.append("")
    if pytest_results:
        for line in pytest_results.splitlines():
            lines.append(line)
    else:
        lines.append("No pytest results provided.")
    lines.append("")
    lines.append("---")
    lines.append("*End of Report*")

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"Markdown report: {output_path}")


def generate_pdf_report(
    evaluation_results: Dict,
    controller_metrics: Dict,
    output_path: str = "docs/Test_Report.pdf",
    screenshot_paths: List[str] = None,
) -> None:
    """Generate PDF test report using ReportLab."""
    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        rightMargin=inch,
        leftMargin=inch,
        topMargin=inch,
        bottomMargin=inch,
        title="AI-Powered Smart Classroom Controller - Test Report",
        author="Smart Classroom Controller",
    )

    styles = {}
    styles["Title"] = ParagraphStyle(
        "Title", fontName="Times-Bold", fontSize=20, alignment=1, spaceAfter=12
    )
    styles["Heading1"] = ParagraphStyle(
        "Heading1", fontName="Times-Bold", fontSize=16, alignment=0, spaceBefore=14, spaceAfter=8
    )
    styles["Body"] = ParagraphStyle(
        "Body", fontName="Times-Roman", fontSize=12, alignment=0, spaceAfter=6
    )
    styles["Bullet"] = ParagraphStyle(
        "Bullet", fontName="Times-Roman", fontSize=12, alignment=0, leftIndent=18, spaceAfter=3
    )

    story = []
    story.append(Paragraph("AI-Powered Smart Classroom Controller", styles["Title"]))
    story.append(Paragraph("Test Report", styles["Heading1"]))
    story.append(Spacer(1, 12))
    story.append(Paragraph(
        f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles["Body"]
    ))
    story.append(Spacer(1, 12))

    story.append(Paragraph("1. Abstract and Objectives", styles["Heading1"]))
    story.append(Paragraph(
        "This report describes the AI-Powered Smart Classroom Controller prototype for automated lighting and fan control.",
        styles["Body"]
    ))

    story.append(Paragraph("2. System Architecture", styles["Heading1"]))
    story.append(Paragraph(
        "The system consists of: IoT Sensor Simulation Module, Control Logic Module, Evaluation Module, and Streamlit App.",
        styles["Body"]
    ))

    story.append(Paragraph("3. Module Descriptions", styles["Heading1"]))
    story.append(Paragraph(
        "The IoT simulator generates occupancy, ambient light, temperature, humidity, and CO2 readings with "
        "configurable noise, dropouts, spikes, and drift.", styles["Body"]
    ))
    story.append(Paragraph(
        "The controller applies threshold-based rules with hysteresis and minimum dwell time to control lights and fans.",
        styles["Body"]
    ))
    story.append(Paragraph(
        "The evaluation harness runs seeded simulations across multiple scenarios and computes accuracy, latency, "
        "energy savings, and false activation rates.", styles["Body"]
    ))

    story.append(Paragraph("4. Results", styles["Heading1"]))
    story.append(Paragraph("4.1 Decision Accuracy", styles["Body"]))
    data_rows = [["Scenario", "Accuracy", "Precision", "Recall", "F1", "Energy Saving %", "False Act Rate"]]
    for scenario, results_data in evaluation_results.items():
        agg = results_data.get("aggregated", {})
        data_rows.append([
            scenario.replace("_", " ").title(),
            "{:.4f}".format(agg.get("avg_accuracy", 0)),
            "{:.4f}".format(agg.get("avg_precision", 0)),
            "{:.4f}".format(agg.get("avg_recall", 0)),
            "{:.4f}".format(agg.get("avg_f1", 0)),
            "{:.2f}".format(agg.get("avg_energy_saving_percent", 0)),
            "{:.4f}".format(agg.get("avg_false_activation_rate", 0)),
        ])
    t = Table(data_rows, colWidths=[1.2*inch, 0.8*inch, 0.9*inch, 0.7*inch, 0.6*inch, 1.1*inch, 0.9*inch])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#0A1020")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("FONTNAME", (0,0), (-1,0), "Times-Bold"),
        ("FONTSIZE", (0,0), (-1,-1), 8),
        ("GRID", (0,0), (-1,-1), 0.5, colors.grey),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#111B30")]),
        ("TEXTCOLOR", (0,1), (-1,-1), colors.white),
        ("FONTNAME", (0,1), (-1,-1), "Times-Roman"),
        ("ALIGN", (1,0), (-1,-1), "CENTER"),
    ]))
    story.append(t)
    story.append(Spacer(1, 12))

    story.append(Paragraph("5. User Interface", styles["Heading1"]))
    story.append(Paragraph(
        "The Streamlit dashboard is a single page with a sidebar mode switcher (Manual - click the seats / "
        "Auto - run simulation) and tabs for Live Dashboard and Evaluation.", styles["Body"]
    ))
    story.append(Paragraph(
        "Header shows title, subtitle, and a Mode chip (MANUAL / AUTO). Sidebar has exactly the mode radio plus, in Manual mode, "
        "an outside-lux slider (0-1000), a room-temperature slider (20-40 C), and Fill all seats / Clear all seats buttons; "
        "in Auto mode, a scenario dropdown (Normal Day, Exam Day, Hot Afternoon, Empty Weekend) plus Start / Pause / Reset. "
        "KPI row shows four cards (Occupancy, Light Level, Temperature, CO2). The classroom hero shows a Whiteboard / Teacher Desk bar "
        "and three zone cards (Front / Middle / Back) with teal dashed borders, zone pill, L1/L2 light indicators, fan indicator, "
        "and a 2x8 grid of clickable seat buttons (48 seats total) that toggle occupancy instantly in Manual mode and mirror "
        "simulator occupancy (disabled) in Auto mode. An outside-light card with sun icon and a legend (ON / OFF / Dimmed) sit beside it. "
        "Decision Log shows the last 5 decisions newest first; Energy shows controller vs baseline power (Manual) or kWh (Auto). "
        "Bottom strip shows Decision Accuracy, Response Latency, and False Activation Rate via evaluation/metrics.py.", styles["Body"]
    ))

    story.append(Paragraph("6. Limitations and Future Work", styles["Heading1"]))
    story.append(Paragraph(
        "This prototype uses simulated sensors and devices. Real IoT hardware integration is future work.",
        styles["Body"]
    ))

    story.append(Paragraph("7. Dashboard Screenshots", styles["Heading1"]))
    if screenshot_paths:
        for sp in screenshot_paths:
            img_path = os.path.abspath(sp)
            if os.path.exists(img_path):
                img = Image(img_path, width=6.5*inch, height=3.4*inch)
                story.append(img)
                story.append(Spacer(1, 6))
                story.append(Paragraph(os.path.basename(sp), styles["Body"]))
                story.append(Spacer(1, 6))
    else:
        story.append(Paragraph("No screenshots available.", styles["Body"]))

    doc.build(story)
    print(f"PDF report: {output_path}")


def generate_all_reports(
    evaluation_results: Dict,
    controller_metrics: Dict,
    markdown_path: str = "docs/Test_Report.md",
    pdf_path: str = "docs/Test_Report.pdf",
    screenshot_paths: List[str] = None,
    pytest_results: str = "",
) -> None:
    """Generate both Markdown and PDF test reports."""
    generate_markdown_report(
        evaluation_results, controller_metrics, markdown_path,
        pytest_results=pytest_results, screenshot_paths=screenshot_paths,
    )
    generate_pdf_report(
        evaluation_results, controller_metrics, pdf_path,
        screenshot_paths=screenshot_paths,
    )
    generate_charts(evaluation_results, "docs/charts")
    print(f"  Markdown report: {markdown_path}")
    print(f"  PDF report: {pdf_path}")


def generate_charts(evaluation_results: Dict, output_dir: str = "docs/charts") -> List[str]:
    """Generate charts for the test report."""
    os.makedirs(output_dir, exist_ok=True)
    chart_files = []
    try:
        scenarios = list(evaluation_results.keys())
        accuracies = [
            evaluation_results[s].get("aggregated", {}).get("avg_accuracy", 0)
            for s in scenarios
        ]
        savings = [
            evaluation_results[s].get("aggregated", {}).get("avg_energy_saving_percent", 0)
            for s in scenarios
        ]

        fig, axes = plt.subplots(1, 2, figsize=(10, 4))
        axes[0].bar(range(len(scenarios)), accuracies, color="steelblue")
        axes[0].set_title("Decision Accuracy by Scenario")
        axes[0].set_ylabel("Accuracy")
        axes[0].set_xticks(range(len(scenarios)))
        axes[0].set_xticklabels([s.replace("_", " ").title() for s in scenarios], rotation=45, ha="right", fontsize=8)

        axes[1].bar(range(len(scenarios)), savings, color="darkorange")
        axes[1].set_title("Energy Saving % by Scenario")
        axes[1].set_ylabel("Energy Saving %")
        axes[1].set_xticks(range(len(scenarios)))
        axes[1].set_xticklabels([s.replace("_", " ").title() for s in scenarios], rotation=45, ha="right", fontsize=8)

        plt.tight_layout()
        chart_path = os.path.join(output_dir, "metrics_by_scenario.png")
        plt.savefig(chart_path, dpi=150)
        plt.close()
        chart_files.append(chart_path)
    except Exception as e:
        print(f"Chart generation failed: {e}")
    return chart_files
