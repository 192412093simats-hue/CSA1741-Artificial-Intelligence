"""Evaluation metrics for the Smart Classroom Controller."""

from dataclasses import dataclass
from datetime import datetime
import numpy as np
from typing import Dict, List, Optional, Tuple
from collections import defaultdict

@dataclass
class AccuracyMetrics:
    """Accuracy metrics for controller vs ground truth."""
    device_accuracy: float  # % of timesteps where controller matched ground truth
    light_precision: float
    light_recall: float
    light_f1: float
    light_confusion_matrix: List[List[int]]
    fan_accuracy: float
    total_timesteps: int
    mismatches: int

@dataclass
class LatencyMetrics:
    """Response latency metrics."""
    mean_latency_seconds: float
    median_latency_seconds: float
    p95_latency_seconds: float
    max_latency_seconds: float
    true_positive_reactions: int
    false_positive_reactions: int

@dataclass
class EnergyMetrics:
    """Energy consumption metrics."""
    controller_kwh: float
    baseline_kwh: float
    energy_saving_percent: float
    cost_controller_inr: float
    cost_baseline_inr: float
    tariff_per_kwh: float  # INR per kWh

@dataclass
class FalseActivationMetrics:
    """False activation rate metrics."""
    false_activation_rate: float  # % of activations that shouldn't have happened
    false_deactivation_rate: float  # % of times controller turned off when should have stayed on
    total_activations: int
    false_activations: int
    true_deactivations: int
    missed_deactivations: int

def compute_device_accuracy(
    actual: Dict,  # device_id -> bool (controller decision)
    ground_truth: Dict,  # device_id -> bool (ideal)
    device_type: str = "light"
) -> Tuple[float, float, float, float, int, int]:
    """Compute accuracy, precision, recall, F1 for a device."""
    # Collect all device IDs of this type
    device_ids = sorted([
        k for k, v in actual.items()
        if (device_type == "light" and k.startswith("LIGHT-"))
        or (device_type == "fan" and k.startswith("FAN-"))
    ])

    tp = fp = fn = tn = 0
    total = 0

    for dev_id in device_ids:
        gt = ground_truth.get(dev_id, False)
        pred = actual.get(dev_id, False)
        total += 1
        if pred and gt:
            tp += 1
        elif pred and not gt:
            fp += 1
        elif gt and not pred:
            fn += 1
        else:
            tn += 1

    accuracy = (tp + tn) / total if total > 0 else 1.0
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0

    return accuracy, precision, recall, f1, tp, (fp + fn)

def compute_energy_usage(
    device_states: List[Dict],
    power_ratings: Dict[str, float],
    seconds_in_day: int = 24*60*60
) -> Tuple[float, float]:
    """Compute kWh consumed by actual vs baseline device usage.

    Args:
        device_states: List of device states with power_watts
        power_ratings: Dict device_id -> power_rating_watts
        seconds_in_day: seconds in simulation period

    Returns:
        (actual_kwh, baseline_kwh)
    """
    actual_kwh = 0.0
    baseline_kwh = 0.0

    for state in device_states:
        dev_id = state.get('device_id', '')
        watts = state.get('power_watts', 0.0)
        actual_kwh += watts * state.get('duration_seconds', seconds_in_day) / 3600.0

        # Baseline: assume same device but always on
        baseline_watts = watts if watts > 0 else 0.0
        # Or use rated power
        baseline_kwh += baseline_watts * state.get('duration_seconds', seconds_in_day) / 3600.0

    return actual_kwh, baseline_kwh

def compute_response_latency(
    actual_events: List[Dict],
    ground_truth_events: List[Dict],
    timestamp_key: str = 'timestamp'
) -> LatencyMetrics:
    """Compute response latency metrics.

    Args:
        actual_events: Device state changes (from controller)
        ground_truth_events: Ideal state changes (from ground truth)

    Returns:
        LatencyMetrics with mean, median, p95 latency
    """
    latencies = []

    # Build time of true condition change
    for gt_event in ground_truth_events:
        gt_time = gt_event.get('timestamp')
        if gt_time is None:
            continue
        # Find actual event close to this time
        for act_event in actual_events:
            act_time = act_event.get('timestamp')
            if act_time is None:
                continue
            delta = abs((act_time - gt_time).total_seconds())
            if delta < 300:  # within 5 minutes
                latencies.append(delta)

    if len(latencies) > 0:
        lat_arr = np.array(latencies)
        return LatencyMetrics(
            mean_latency_seconds=float(np.mean(lat_arr)),
            median_latency_seconds=float(np.median(lat_arr)),
            p95_latency_seconds=float(np.percentile(lat_arr, 95)),
            max_latency_seconds=float(np.max(lat_arr)),
            true_positive_reactions=len(latencies),
            false_positive_reactions=0
        )

    return LatencyMetrics(
        mean_latency_seconds=0.0,
        median_latency_seconds=0.0,
        p95_latency_seconds=0.0,
        max_latency_seconds=0.0,
        true_positive_reactions=0,
        false_positive_reactions=0
    )

def compute_false_activation_rate(
    device_actions: List[Dict],
    ground_truth_states: Dict[str, bool],
    device_id: str,
    timestamp: datetime
) -> float:
    """Compute false activation rate for a device."""
    activations = [a for a in device_actions if a.get('device_id') == device_id and a.get('action') == 'on']
    false_activations = 0

    for act in activations:
        gt_state = ground_truth_states.get(device_id, False)
        if not gt_state:
            false_activations += 1

    total = len(activations)
    if total == 0:
        return 0.0
    return false_activations / total

def compute_all_metrics(
    decisions: List[Dict],
    ground_truth_history: List[Dict],
    device_configs: Dict[str, Dict]
) -> Dict:
    """Compute all evaluation metrics."""
    # Decision accuracy
    accuracy = 0.0
    correct = 0
    total = 0

    for decision in decisions:
        # Check each zone/device
        for cmd in decision.get('commands', []):
            dev_id = cmd.get('device_id')
            if dev_id and dev_id in device_configs:
                # Get ground truth state
                gt_state = ground_truth_history.get(dev_id, {}).get('state', False)
                pred_state = cmd.get('params', {}).get('on', False)

                total += 1
                if pred_state == gt_state:
                    correct += 1

    accuracy = correct / total if total > 0 else 1.0

    # Energy calculation
    energy = compute_energy_usage(
        [d for decision in decisions for d in decision.get('commands', [])],
        {d['device_id']: d.get('power_rating_watts', 0) for d in device_configs.values()}
    )

    return {
        'decision_accuracy': accuracy,
        'energy_kwh': energy[0],
        'baseline_energy_kwh': energy[1],
        'false_activation_rate': 0.0,  # Computed separately
        'latency': None,
        'device_metrics': {}
    }
