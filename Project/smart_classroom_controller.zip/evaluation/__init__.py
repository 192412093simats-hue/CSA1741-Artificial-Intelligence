"""Evaluation package for the Smart Classroom Controller."""

from .metrics import (
    AccuracyMetrics, LatencyMetrics, EnergyMetrics, FalseActivationMetrics,
    compute_device_accuracy, compute_response_latency, compute_false_activation_rate,
    compute_energy_usage, compute_all_metrics
)
from .run_evaluation import (
    run_scenario_evaluation, run_full_evaluation, save_results_json
)
from .report_generator import (
    generate_markdown_report, generate_pdf_report, generate_all_reports, generate_charts
)

__all__ = [
    "AccuracyMetrics", "LatencyMetrics", "EnergyMetrics", "FalseActivationMetrics",
    "compute_device_accuracy", "compute_response_latency", "compute_false_activation_rate",
    "compute_energy_usage", "compute_all_metrics",
    "run_scenario_evaluation", "run_full_evaluation", "save_results_json",
    "generate_markdown_report", "generate_pdf_report", "generate_all_reports", "generate_charts",
]