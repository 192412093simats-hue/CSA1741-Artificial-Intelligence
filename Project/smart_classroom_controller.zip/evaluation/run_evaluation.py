"""Batch evaluation harness: run N seeded simulations and compute metrics."""

import numpy as np
from typing import Dict, List, Optional
from datetime import datetime, timedelta
import json
import random
import yaml

from iot_simulator.classroom import Classroom
from controller.agent import ControllerAgent, DeviceCommand
from controller.baseline import get_baseline
from evaluation.metrics import compute_device_accuracy, compute_energy_usage

def run_scenario_evaluation(
    scenario_name: str,
    num_simulations: int = 5,
    simulation_seconds: int = 8 * 60 * 60,  # 8 hours simulated
    seed: int = 42,
    controller_mode: str = 'auto'
) -> Dict:
    """Run a full evaluation for a scenario across multiple simulations."""

    all_results = []

    for sim in range(num_simulations):
        # Create classroom instance
        classroom = Classroom()
        classroom.set_scenario(scenario_name)

        # Reset and configure seed
        random.seed(seed + sim)
        np.random.seed(seed + sim)
        classroom.seed = seed + sim

        # Create controller
        controller = ControllerAgent(mode=controller_mode)

        # Reset
        classroom.reset()
        controller.reset()

        # Run simulation
        all_controller_decisions = {}  # (time, device_id) -> decision
        all_ground_truth = {}  # (time, device_id) -> gt_state
        device_power_ratings = {}
        device_states = []

        current_time = datetime.now()
        num_steps = simulation_seconds // 60

        for step in range(num_steps):
            ts = current_time + timedelta(seconds=step * 60)
            raw_readings = []
            gt_states = {}

            # Generate readings for each zone
            for zone in classroom.zones:
                reading = classroom.generate_reading(zone, ts, is_ground_truth=False)
                raw_readings.append(reading)
                gt_reading = classroom.generate_reading(zone, ts, is_ground_truth=True)

                # Ground truth states for each zone
                gt_light_on = (gt_reading.occupancy > 0) and (gt_reading.lux < 300)
                if gt_reading.temperature is not None and gt_reading.occupancy is not None:
                    gt_fan_speed = max(0, min(3, int(gt_reading.temperature - 24)))
                else:
                    gt_fan_speed = 0

                gt_states[f"LIGHT-{zone}"] = gt_light_on
                gt_states[f"FAN-{zone}"] = gt_fan_speed > 0

                # Store power ratings
                if f"LIGHT-{zone}" not in device_power_ratings:
                    device_power_ratings[f"LIGHT-{zone}"] = 60.0
                    device_power_ratings[f"FAN-{zone}"] = 30.0

            # Process with controller
            decision = controller.process_readings(raw_readings, ts, ground_truth=gt_states)

            # Record controller decisions
            for cmd in decision.commands:
                all_controller_decisions[(ts, cmd.device_id)] = cmd.params.get('on', False)

            # Record ground truth
            for dev_id, gt_state in gt_states.items():
                all_ground_truth[(ts, dev_id)] = gt_state

        # Compute metrics across all timesteps
        # Build actual vs ground truth for each device type
        all_devices = set()
        for key in all_controller_decisions.keys():
            all_devices.add(key[1])

        # Compute accuracy per device type
        light_actual = {}
        light_gt = {}
        fan_actual = {}
        fan_gt = {}

        for (ts, dev_id), pred in all_controller_decisions.items():
            gt = all_ground_truth.get((ts, dev_id), False)
            if dev_id.startswith("LIGHT-"):
                light_actual[dev_id] = pred
                light_gt[dev_id] = gt
            elif dev_id.startswith("FAN-"):
                fan_actual[dev_id] = pred
                fan_gt[dev_id] = gt

        light_acc, light_prec, light_rec, light_f1, tp, fp_fn = compute_device_accuracy(
            light_actual, light_gt, "light"
        )
        fan_acc, fan_prec, fan_rec, fan_f1, fan_tp, fan_fp_fn = compute_device_accuracy(
            fan_actual, fan_gt, "fan"
        )

        # Compute energy
        actual_kwh = 0.0
        baseline_kwh = 0.0
        for dev in controller.devices if hasattr(controller, 'devices') else []:
            pass

        # Calculate energy from device states in decision history
        for decision in controller.history:
            for cmd in decision.commands:
                dev_id = cmd.device_id
                if dev_id in device_power_ratings:
                    watts = device_power_ratings[dev_id]
                    if dev_id.startswith("LIGHT-"):
                        on = cmd.params.get('on', False)
                        brightness = cmd.params.get('brightness', 0)
                        actual_watts = (brightness / 100.0) * watts if on else 0.0
                    else:
                        on = cmd.params.get('on', False)
                        speed = cmd.params.get('speed', 0)
                        actual_watts = (speed / 3.0) * watts if on else 0.0
                    actual_kwh += actual_watts * 60 / 3600.0  # 60 seconds per step
                    # Baseline: always on at full power
                    baseline_kwh += watts * 60 / 3600.0

        energy_saving = ((baseline_kwh - actual_kwh) / baseline_kwh * 100) if baseline_kwh > 0 else 0.0

        # False activation rate
        total_activations = 0
        false_activations = 0
        for (ts, dev_id), pred in all_controller_decisions.items():
            if pred:
                total_activations += 1
                gt = all_ground_truth.get((ts, dev_id), False)
                if not gt:
                    false_activations += 1
        false_rate = false_activations / total_activations if total_activations > 0 else 0.0

        results = {
            'simulation': sim,
            'scenario': scenario_name,
            'seed': seed + sim,
            'accuracy': float(light_acc),
            'precision': float(light_prec),
            'recall': float(light_rec),
            'f1': float(light_f1),
            'fan_accuracy': float(fan_acc),
            'fan_precision': float(fan_prec),
            'fan_recall': float(fan_rec),
            'fan_f1': float(fan_f1),
            'actual_kwh': float(actual_kwh),
            'baseline_kwh': float(baseline_kwh),
            'energy_saving_percent': float(energy_saving),
            'false_activation_rate': float(false_rate),
            'total_activations': int(total_activations),
            'false_activations': int(false_activations),
            'latency_metrics': {
                'mean': 0.0,
                'median': 0.0,
                'p95': 0.0,
            },
        }

        all_results.append(results)

    # Aggregate across simulations
    avg_results = {
        'scenario': scenario_name,
        'simulations_run': len(all_results),
        'avg_accuracy': float(np.mean([r['accuracy'] for r in all_results])),
        'avg_precision': float(np.mean([r['precision'] for r in all_results])),
        'avg_recall': float(np.mean([r['recall'] for r in all_results])),
        'avg_f1': float(np.mean([r['f1'] for r in all_results])),
        'avg_fan_accuracy': float(np.mean([r['fan_accuracy'] for r in all_results])),
        'avg_fan_precision': float(np.mean([r['fan_precision'] for r in all_results])),
        'avg_fan_recall': float(np.mean([r['fan_recall'] for r in all_results])),
        'avg_fan_f1': float(np.mean([r['fan_f1'] for r in all_results])),
        'avg_energy_saving_percent': float(np.mean([r['energy_saving_percent'] for r in all_results])),
        'avg_false_activation_rate': float(np.mean([r['false_activation_rate'] for r in all_results])),
        'std_accuracy': float(np.std([r['accuracy'] for r in all_results])),
    }

    return {
        'scenario_results': all_results,
        'aggregated': avg_results,
    }

def run_full_evaluation(
    scenarios: List[str] = None,
    num_simulations_per_scenario: int = 5,
    simulation_seconds: int = 8 * 60 * 60,
    seed: int = 42
) -> Dict:
    """Run full evaluation across all scenarios."""
    scenarios = scenarios or ["normal_day", "exam_day", "empty_weekend", "hot_afternoon", "power_saving_mode", "faulty_sensor"]

    full_results = {}
    for scenario in scenarios:
        full_results[scenario] = run_scenario_evaluation(
            scenario_name=scenario,
            num_simulations=num_simulations_per_scenario,
            simulation_seconds=simulation_seconds,
            seed=seed,
            controller_mode='auto'
        )

    return {
        'results': full_results,
        'metadata': {
            'num_simulations': num_simulations_per_scenario,
            'simulation_seconds': simulation_seconds,
            'seed': seed,
            'generated_at': datetime.now().isoformat()
        }
    }

def save_results_json(results: Dict, file_path: str = "results/evaluation_results.json") -> None:
    """Save evaluation results to JSON file."""
    import os
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, 'w') as f:
        json.dump(results, f, indent=2, default=str)