# Smart Classroom Controller

AI-powered smart classroom controller (Python): simulates IoT sensors, applies transparent threshold-based rules to control lights/fans, evaluates decisions against baselines, and shows a Streamlit dashboard.

## Run

```powershell
.venv\Scripts\Activate.ps1
streamlit run app.py        # http://localhost:8501
```

## Test / eval / report

```powershell
.venv\Scripts\python.exe -m pytest -v
.venv\Scripts\python.exe scripts/run_eval.py
.venv\Scripts\python.exe scripts/gen_reports.py
.venv\Scripts\python.exe scripts/ui_check.py   # Playwright UI acceptance
```

## Layout

- `app.py` — Streamlit page flow + session state (ONE state object).
- `ui/theme.py` — dark palette + STYLESHEET CSS. `ui/classroom.py` — zone cards + seat grid. `ui/cards.py` — KPI/log/energy/metrics cards.
- `controller/rules.py` — `decide_zone_state()` pure per-zone rule (Manual, immediate) + `RuleEngine` (Auto, dwell/hysteresis). `controller/agent.py` — ControllerAgent.
- `iot_simulator/` — sensors/devices/scenarios. `evaluation/metrics.py` — the ONLY metric implementations (reuse, never duplicate).
- `tests/test_rules.py` — includes TestManualDecisions.
- `config/thresholds.yaml`, `config/scenarios.yaml`.

## Rules

- One state object in `st.session_state`; None sensor values render as "--"; never crash.
- Manual mode is event-driven (no loops); Auto advances the simulator then `st.rerun()` (Streamlit 1.36 has no st.fragment).
- All numbers on screen come from the same state object.
- Keep UI code minimal: app.py + ui/theme.py + ui/classroom.py + ui/cards.py only.
- Fonts >= 14px, no overlapping text, dark navy + neon teal/amber theme.
