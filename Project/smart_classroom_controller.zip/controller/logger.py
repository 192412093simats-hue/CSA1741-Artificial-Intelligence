"""Decision logging for explainability."""

import json
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional
from datetime import datetime
import csv
import os

@dataclass
class DecisionLog:
    """A single logged decision."""
    timestamp: str
    zone: str
    device_id: str
    device_type: str
    rule_name: str
    action: str
    reason: str
    inputs: Dict
    mode: str  # 'auto', 'manual', 'recommend'

class DecisionLogger:
    """Logs all controller decisions for explainability and evaluation."""

    def __init__(self, log_file: str = "results/decisions.csv"):
        self.log_file = log_file
        self.logs: List[DecisionLog] = []
        os.makedirs(os.path.dirname(log_file), exist_ok=True)

        # Initialize CSV with headers if new
        if not os.path.exists(log_file):
            with open(log_file, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([
                    'timestamp', 'zone', 'device_id', 'device_type',
                    'rule_name', 'action', 'reason', 'inputs_json', 'mode'
                ])

    def log(self, decision: DecisionLog) -> None:
        """Log a decision."""
        self.logs.append(decision)
        self._write_csv(decision)

    def _write_csv(self, decision: DecisionLog) -> None:
        """Write a single decision to CSV."""
        with open(self.log_file, 'a', newline='') as f:
            writer = csv.writer(f)
            writer.writerow([
                decision.timestamp,
                decision.zone,
                decision.device_id,
                decision.device_type,
                decision.rule_name,
                decision.action,
                decision.reason,
                json.dumps(decision.inputs),
                decision.mode
            ])

    def get_logs(self, zone: Optional[str] = None,
                 device_type: Optional[str] = None,
                 start_time: Optional[datetime] = None,
                 end_time: Optional[datetime] = None) -> List[DecisionLog]:
        """Filter logs by criteria."""
        filtered = self.logs
        if zone:
            filtered = [l for l in filtered if l.zone == zone]
        if device_type:
            filtered = [l for l in filtered if l.device_type == device_type]
        if start_time:
            filtered = [l for l in filtered if datetime.fromisoformat(l.timestamp) >= start_time]
        if end_time:
            filtered = [l for l in filtered if datetime.fromisoformat(l.timestamp) <= end_time]
        return filtered

    def clear(self) -> None:
        """Clear in-memory logs."""
        self.logs.clear()

    def export_json(self, file_path: str) -> None:
        """Export all logs to JSON."""
        with open(file_path, 'w') as f:
            json.dump([asdict(l) for l in self.logs], f, indent=2)

def log_decision(logger: DecisionLogger, zone: str, device_id: str,
                 device_type: str, rule_name: str, action: str,
                 reason: str, inputs: Dict, mode: str) -> DecisionLog:
    """Helper to create and log a decision."""
    log_entry = DecisionLog(
        timestamp=datetime.now().isoformat(),
        zone=zone,
        device_id=device_id,
        device_type=device_type,
        rule_name=rule_name,
        action=action,
        reason=reason,
        inputs=inputs,
        mode=mode
    )
    logger.log(log_entry)
    return log_entry