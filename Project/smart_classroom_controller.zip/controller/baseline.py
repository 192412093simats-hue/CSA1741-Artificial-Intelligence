"""Baseline controllers for energy comparison."""

from typing import Dict, List
from datetime import datetime
from dataclasses import dataclass, field

@dataclass
class BaselineState:
    """State of a baseline controller."""
    lights_on: Dict[str, bool] = field(default_factory=dict)
    fan_speeds: Dict[str, int] = field(default_factory=dict)
    name: str = "baseline"

class AlwaysOnBaseline:
    """Baseline: lights always on at full brightness, fans always at speed 1."""

    def __init__(self):
        self.name = "always_on"
        self.state = BaselineState()

    def decide(self, readings: List, current_time: datetime) -> Dict:
        """Make baseline decisions."""
        decisions = {}

        for reading in readings:
            zone = reading.zone
            device_id = f"LIGHT-{zone}"
            # Lights always on at 100%
            decisions[device_id] = {'on': True, 'brightness': 100}

            device_id = f"FAN-{zone}"
            # Fans always at speed 1 if occupied, else off
            occupancy = reading.occupancy or 0
            decisions[device_id] = {'on': occupancy > 0, 'speed': 1 if occupancy > 0 else 0}

        return decisions

class TimerBaseline:
    """Baseline: lights on during scheduled hours, fans on when occupied."""

    def __init__(self, schedule_start: int = 8*60, schedule_end: int = 17*60):
        self.name = "timer"
        self.schedule_start = schedule_start  # minutes since midnight
        self.schedule_end = schedule_end

    def _in_schedule(self, current_time: datetime) -> bool:
        minutes = current_time.hour * 60 + current_time.minute
        return self.schedule_start <= minutes < self.schedule_end

    def decide(self, readings: List, current_time: datetime) -> Dict:
        """Make baseline decisions based on schedule."""
        decisions = {}
        in_sched = self._in_schedule(current_time)

        for reading in readings:
            zone = reading.zone
            occupancy = reading.occupancy or 0

            device_id = f"LIGHT-{zone}"
            # Lights on during scheduled hours
            decisions[device_id] = {'on': in_sched, 'brightness': 80 if in_sched else 0}

            device_id = f"FAN-{zone}"
            # Fans on during scheduled hours if occupied
            if in_sched and occupancy > 0:
                decisions[device_id] = {'on': True, 'speed': 2}
            else:
                decisions[device_id] = {'on': False, 'speed': 0}

        return decisions

class NaiveThresholdBaseline:
    """Baseline: simple threshold without hysteresis or dwell time."""

    def __init__(self):
        self.name = "naive_threshold"
        # Same thresholds as main controller but no hysteresis/dwell
        self.lux_on = 300
        self.lux_off = 300  # No hysteresis
        self.temp_on = 26.0
        self.co2_limit = 1000

    def decide(self, readings: List, current_time: datetime) -> Dict:
        """Make naive threshold decisions."""
        decisions = {}

        for reading in readings:
            zone = reading.zone
            lux = reading.lux or 0
            temp = reading.temperature or 20
            co2 = reading.co2 or 400
            occupancy = reading.occupancy or 0

            # Lights: simple on/off at same threshold
            device_id = f"LIGHT-{zone}"
            if occupancy > 0 and lux < self.lux_on:
                decisions[device_id] = {'on': True, 'brightness': 50}
            elif lux >= self.lux_off:
                decisions[device_id] = {'on': False, 'brightness': 0}
            else:
                decisions[device_id] = {'on': False, 'brightness': 0}

            # Fans: simple on/off
            device_id = f"FAN-{zone}"
            target_speed = 0
            if temp >= self.temp_on:
                target_speed = max(target_speed, 1)
            if co2 >= self.co2_limit:
                target_speed = max(target_speed, 2)
            if occupancy > 0:
                target_speed = max(target_speed, 1)

            decisions[device_id] = {'on': target_speed > 0, 'speed': target_speed}

        return decisions

def get_baseline(name: str):
    """Get baseline controller by name."""
    baselines = {
        'always_on': AlwaysOnBaseline(),
        'timer': TimerBaseline(),
        'naive': NaiveThresholdBaseline(),
    }
    return baselines.get(name, AlwaysOnBaseline())