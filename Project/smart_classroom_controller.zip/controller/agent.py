"""Main controller agent that applies rules and manages devices."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Literal
from datetime import datetime
import logging

from .rules import RuleEngine, RuleResult
from .filters import SensorFilterPipeline, FilteredReading
from .baseline import get_baseline
from .logger import DecisionLogger, DecisionLog, log_decision

logger = logging.getLogger(__name__)

Mode = Literal['auto', 'manual', 'recommend']

@dataclass
class DeviceCommand:
    """Command to send to a device."""
    device_id: str
    zone: str
    device_type: str
    action: str  # 'on', 'off', 'set'
    params: Dict
    timestamp: datetime
    rule_name: str
    reason: str

@dataclass
class Decision:
    """A complete decision with all commands and metadata."""
    timestamp: datetime
    commands: List[DeviceCommand]
    mode: Mode
    raw_readings: List
    filtered_readings: Dict[str, FilteredReading]
    log_entries: List[DecisionLog]

class ControllerAgent:
    """Main controller that makes decisions based on sensor readings."""

    def __init__(self, mode: Mode = 'auto', thresholds_file: str = "config/thresholds.yaml"):
        self.mode: Mode = mode
        self.rule_engine = RuleEngine(thresholds_file)
        self.filter_pipeline = SensorFilterPipeline()
        self.decision_logger = DecisionLogger()
        self.baseline = get_baseline('always_on')  # Default baseline for comparison
        self.manual_overrides: Dict[str, Dict] = {}  # device_id -> state
        self.history: List[Decision] = []

        # Ground truth tracking
        self.ground_truth_states: Dict[str, Dict] = {}

    def set_mode(self, mode: Mode) -> None:
        """Set controller mode."""
        self.mode = mode
        logger.info(f"Controller mode set to: {mode}")

    def set_baseline(self, name: str) -> None:
        """Set baseline controller for comparison."""
        self.baseline = get_baseline(name)
        logger.info(f"Baseline set to: {name}")

    def set_manual_override(self, device_id: str, state: Dict) -> None:
        """Set a manual override for a device."""
        self.manual_overrides[device_id] = state
        logger.info(f"Manual override set for {device_id}: {state}")

    def clear_manual_override(self, device_id: str) -> None:
        """Clear manual override for a device."""
        if device_id in self.manual_overrides:
            del self.manual_overrides[device_id]

    def clear_all_overrides(self) -> None:
        """Clear all manual overrides."""
        self.manual_overrides.clear()

    def process_readings(self, raw_readings: List, current_time: datetime,
                         ground_truth: Optional[Dict] = None) -> Decision:
        """Process sensor readings and produce device commands."""
        # Filter all readings
        filtered_readings = {}
        for reading in raw_readings:
            zone = reading.zone
            for sensor_type in ['occupancy', 'lux', 'temperature', 'humidity', 'co2']:
                raw_val = getattr(reading, sensor_type)
                key = f"{sensor_type}_{zone}"
                filtered = self.filter_pipeline.process(
                    sensor_type, zone, raw_val, current_time)
                filtered_readings[key] = filtered

        # Store ground truth for evaluation
        if ground_truth:
            self.ground_truth_states = ground_truth

        # Evaluate rules based on mode
        commands = []
        log_entries = []

        if self.mode == 'auto':
            commands, log_entries = self._auto_decide(filtered_readings, raw_readings, current_time)
        elif self.mode == 'recommend':
            commands, log_entries = self._recommend(filtered_readings, raw_readings, current_time)
        # In manual mode, no automatic commands are generated

        # Apply manual overrides
        final_commands = self._apply_overrides(commands)

        # Create decision record
        decision = Decision(
            timestamp=current_time,
            commands=final_commands,
            mode=self.mode,
            raw_readings=raw_readings,
            filtered_readings=filtered_readings,
            log_entries=log_entries
        )

        self.history.append(decision)
        return decision

    def _auto_decide(self, filtered_readings: Dict, raw_readings: List,
                     current_time: datetime) -> tuple[List[DeviceCommand], List[DecisionLog]]:
        """Make automatic decisions based on filtered readings."""
        commands = []
        log_entries = []

        # Group readings by zone
        by_zone: Dict[str, Dict[str, float]] = {}
        for reading in raw_readings:
            zone = reading.zone
            if zone not in by_zone:
                by_zone[zone] = {}
            for sensor_type in ['occupancy', 'lux', 'temperature', 'humidity', 'co2']:
                key = f"{sensor_type}_{zone}"
                if key in filtered_readings:
                    by_zone[zone][sensor_type] = filtered_readings[key].filtered

        # Evaluate rules for each zone
        for zone, sensors in by_zone.items():
            # Create a pseudo-reading object for the rule engine
            class SensorData:
                def __init__(self, **kwargs):
                    for k, v in kwargs.items():
                        setattr(self, k, v)

            sensor_data = SensorData(**sensors)

            # Evaluate light rules
            light_results = self.rule_engine.evaluate_lights(zone, sensor_data, current_time)
            for result in light_results:
                cmd = DeviceCommand(
                    device_id=result.device_id,
                    zone=zone,
                    device_type="light",
                    action="set",
                    params={'on': result.action == 'on', 'brightness': 80 if result.action == 'on' else 0},
                    timestamp=current_time,
                    rule_name=result.rule_name,
                    reason=result.reason
                )
                commands.append(cmd)

                log_entry = log_decision(
                    self.decision_logger, zone, result.device_id, "light",
                    result.rule_name, result.action, result.reason,
                    sensors, self.mode
                )
                log_entries.append(log_entry)

            # Evaluate fan rules
            fan_results = self.rule_engine.evaluate_fans(zone, sensor_data, current_time)
            for result in fan_results:
                speed = int(result.action.split('_')[-1])
                cmd = DeviceCommand(
                    device_id=result.device_id,
                    zone=zone,
                    device_type="fan",
                    action="set",
                    params={'on': speed > 0, 'speed': speed},
                    timestamp=current_time,
                    rule_name=result.rule_name,
                    reason=result.reason
                )
                commands.append(cmd)

                log_entry = log_decision(
                    self.decision_logger, zone, result.device_id, "fan",
                    result.rule_name, result.action, result.reason,
                    sensors, self.mode
                )
                log_entries.append(log_entry)

        return commands, log_entries

    def _recommend(self, filtered_readings: Dict, raw_readings: List,
                   current_time: datetime) -> tuple[List[DeviceCommand], List[DecisionLog]]:
        """Generate recommendations without applying them."""
        # Same logic as auto but with 'recommend' mode
        # The difference is semantic - in UI this shows suggestions without applying
        commands, log_entries = self._auto_decide(filtered_readings, raw_readings, current_time)
        # Mark as recommendations
        for cmd in commands:
            cmd.action = "recommend_" + cmd.action
        return commands, log_entries

    def _apply_overrides(self, commands: List[DeviceCommand]) -> List[DeviceCommand]:
        """Apply manual overrides to commands."""
        if not self.manual_overrides:
            return commands

        # Create new list with overrides applied
        final = []
        for cmd in commands:
            if cmd.device_id in self.manual_overrides:
                # Skip auto command - override takes precedence
                continue
            final.append(cmd)

        # Add override commands
        for device_id, state in self.manual_overrides.items():
            # Determine device type and zone from device_id
            parts = device_id.split('-')
            if len(parts) >= 2:
                device_type = parts[0].lower()
                zone = parts[1]
            else:
                device_type = "unknown"
                zone = "unknown"

            final.append(DeviceCommand(
                device_id=device_id,
                zone=zone,
                device_type=device_type,
                action="manual",
                params=state,
                timestamp=datetime.now(),
                rule_name="manual_override",
                reason="Manual override active"
            ))

        return final

    def get_baseline_decision(self, raw_readings: List, current_time: datetime) -> Dict:
        """Get baseline controller decision for energy comparison."""
        return self.baseline.decide(raw_readings, current_time)

    def get_device_state(self, device_id: str) -> Dict:
        """Get current state of a device from history."""
        # Look through history for latest state of this device
        for decision in reversed(self.history):
            for cmd in decision.commands:
                if cmd.device_id == device_id:
                    return cmd.params
        return {}

    def get_thresholds(self) -> dict:
        """Get current threshold values."""
        return self.rule_engine.get_thresholds()

    def set_thresholds(self, **kwargs) -> None:
        """Update threshold values."""
        self.rule_engine.set_thresholds(**kwargs)

    def reset_filters(self) -> None:
        """Reset all filter states."""
        self.filter_pipeline.reset()

    def reset(self) -> None:
        """Reset controller state."""
        self.history.clear()
        self.manual_overrides.clear()
        self.filter_pipeline.reset()
        self.ground_truth_states.clear()
        self.decision_logger.clear()