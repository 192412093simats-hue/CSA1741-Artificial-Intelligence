"""Sensor validation, filtering, and dropout handling."""

from dataclasses import dataclass
from typing import Optional, Dict, List, Deque
from collections import deque
from datetime import datetime
import numpy as np

@dataclass
class FilteredReading:
    """A sensor reading after filtering and validation."""
    raw: Optional[float]
    filtered: Optional[float]
    valid: bool
    dropped: bool
    smoothed: Optional[float]
    sensor_type: str
    zone: str
    timestamp: datetime

class SensorValidator:
    """Validates sensor readings against expected ranges."""

    # Valid ranges for each sensor type
    RANGES = {
        'occupancy': (0, 100),
        'lux': (0, 2000),
        'temperature': (10, 50),
        'humidity': (0, 100),
        'co2': (300, 5000)
    }

    @classmethod
    def validate(cls, value: Optional[float], sensor_type: str) -> bool:
        """Check if a reading is within valid range."""
        if value is None:
            return False
        if sensor_type not in cls.RANGES:
            return True
        low, high = cls.RANGES[sensor_type]
        return low <= value <= high

    @classmethod
    def clamp(cls, value: float, sensor_type: str) -> float:
        """Clamp value to valid range."""
        if sensor_type not in cls.RANGES:
            return value
        low, high = cls.RANGES[sensor_type]
        return max(low, min(high, value))

class MovingAverageFilter:
    """Simple moving average filter for smoothing sensor readings."""

    def __init__(self, window_size: int = 5):
        self.window_size = window_size
        self.buffers: Dict[str, Deque[float]] = {}

    def update(self, key: str, value: Optional[float]) -> Optional[float]:
        """Add a value and return the filtered value."""
        if value is None:
            return None

        if key not in self.buffers:
            self.buffers[key] = deque(maxlen=self.window_size)

        self.buffers[key].append(value)
        if len(self.buffers[key]) > 0:
            return float(np.mean(self.buffers[key]))
        return None

    def get_last(self, key: str) -> Optional[float]:
        """Get the last valid filtered value."""
        if key in self.buffers and len(self.buffers[key]) > 0:
            return self.buffers[key][-1]
        return None

class MedianFilter:
    """Median filter for outlier rejection."""

    def __init__(self, window_size: int = 5):
        self.window_size = window_size
        self.buffers: Dict[str, Deque[float]] = {}

    def update(self, key: str, value: Optional[float]) -> Optional[float]:
        """Add a value and return the median."""
        if value is None:
            return None

        if key not in self.buffers:
            self.buffers[key] = deque(maxlen=self.window_size)

        self.buffers[key].append(value)
        if len(self.buffers[key]) > 0:
            return float(np.median(self.buffers[key]))
        return None

class DropoutHandler:
    """Handles sensor dropouts by falling back to last good value."""

    def __init__(self, timeout_seconds: int = 30):
        self.timeout_seconds = timeout_seconds
        self.last_good: Dict[str, float] = {}
        self.last_good_time: Dict[str, datetime] = {}

    def update(self, key: str, value: Optional[float], timestamp: datetime) -> Optional[float]:
        """Update with a reading, return the best available value."""
        if value is not None:
            self.last_good[key] = value
            self.last_good_time[key] = timestamp
            return value

        # Value is None - check if we have a recent good value
        if key in self.last_good:
            elapsed = (timestamp - self.last_good_time[key]).total_seconds()
            if elapsed <= self.timeout_seconds:
                return self.last_good[key]
            else:
                # Too old - sensor considered failed
                return None

        return None

class SensorFilterPipeline:
    """Complete sensor filtering pipeline: validate -> median -> dropout -> moving avg."""

    def __init__(self, timeout_seconds: int = 30, window_size: int = 5):
        self.validator = SensorValidator()
        self.median_filter = MedianFilter(window_size)
        self.dropout_handler = DropoutHandler(timeout_seconds)
        self.moving_avg = MovingAverageFilter(window_size)

    def process(self, sensor_type: str, zone: str, raw_value: Optional[float],
                timestamp: datetime) -> FilteredReading:
        """Process a single sensor reading through the full pipeline."""
        # Step 1: Validate range
        valid = self.validator.validate(raw_value, sensor_type)
        clamped = self.validator.clamp(raw_value, sensor_type) if valid and raw_value is not None else None

        # Step 2: Median filter for outlier rejection
        median_val = self.median_filter.update(f"{sensor_type}_{zone}", clamped)

        # Step 3: Handle dropouts (use last good value)
        dropout_val = self.dropout_handler.update(f"{sensor_type}_{zone}", median_val, timestamp)

        # Step 4: Moving average smoothing
        smoothed = self.moving_avg.update(f"{sensor_type}_{zone}", dropout_val)

        # Final result
        is_dropped = raw_value is None
        return FilteredReading(
            raw=raw_value,
            filtered=smoothed,
            valid=valid or dropout_val is not None,
            dropped=is_dropped and dropout_val is None,
            smoothed=smoothed,
            sensor_type=sensor_type,
            zone=zone,
            timestamp=timestamp
        )

    def reset(self) -> None:
        """Reset all filter states."""
        self.median_filter.buffers.clear()
        self.dropout_handler.last_good.clear()
        self.dropout_handler.last_good_time.clear()
        self.moving_avg.buffers.clear()