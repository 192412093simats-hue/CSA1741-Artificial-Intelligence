"""Rule-based decision logic for the Smart Classroom Controller."""

import yaml
from dataclasses import dataclass
from typing import Dict, Optional, List
from datetime import datetime, timedelta

@dataclass
class RuleResult:
    """Result of evaluating a rule."""
    rule_name: str
    fired: bool
    action: str
    reason: str
    device_id: str
    device_type: str
    zone: str
    timestamp: datetime

class RuleEngine:
    """Evaluates rules based on sensor inputs and threshold configuration."""

    def __init__(self, thresholds_file: str = "config/thresholds.yaml"):
        with open(thresholds_file, 'r') as f:
            self.config = yaml.safe_load(f)

        # Extract thresholds
        lights = self.config.get('lights', {})
        fans = self.config.get('fans', {})
        occupancy = self.config.get('occupancy', {})
        general = self.config.get('general', {})

        self.lux_low = lights.get('lux_low', 300)
        self.lux_high = lights.get('lux_high', 500)
        self.vacancy_timeout = lights.get('vacancy_timeout_seconds', 120)
        self.dimming_step = lights.get('dimming_step', 25)

        self.temp_on = fans.get('temp_on', 26.0)
        self.temp_off = fans.get('temp_off', 24.0)
        self.co2_limit = fans.get('co2_limit', 1000)
        self.min_fan_speed = fans.get('min_speed', 1)

        self.occupancy_min = occupancy.get('occupancy_min', 1)
        self.dwell_time = general.get('dwell_time_seconds', 30)

        # Track state for dwell time and hysteresis
        self.last_action_time: Dict[str, datetime] = {}
        self.last_device_state: Dict[str, bool] = {}

        # Track last known good values per sensor key (e.g. "lux_front")
        self.last_good: Dict[str, float] = {}

    def _get_last_good(self, key: str, value: Optional[float]) -> Optional[float]:
        """Return the last good value for a sensor key, falling back when current is None."""
        if value is not None:
            # Remember this good value for future dropouts
            self.last_good[key] = value
            return value
        # Sensor dropout - fall back to the last good value
        return self.last_good.get(key)

    def evaluate_lights(self, zone: str, reading, timestamp: datetime) -> List[RuleResult]:
        """Evaluate light control rules for a zone."""
        results = []

        # Get sensor values, falling back to last good value on dropout
        lux = self._get_last_good(f"lux_{zone}", reading.lux)
        occupancy = self._get_last_good(f"occupancy_{zone}", reading.occupancy)

        if lux is None or occupancy is None:
            # No valid readings available - nothing to decide
            return results

        # Rule 1: Turn on lights if occupied AND lux below low threshold
        if occupancy >= self.occupancy_min and lux < self.lux_low:
            # Check dwell time
            key = f"light_{zone}_on"
            if self._check_dwell(key, timestamp):
                results.append(RuleResult(
                    rule_name="lights_on_low_lux",
                    fired=True,
                    action="on",
                    reason=f"Occupied ({occupancy} people) and lux ({lux:.0f}) < {self.lux_low}",
                    device_id=f"LIGHT-{zone}",
                    device_type="light",
                    zone=zone,
                    timestamp=timestamp
                ))

        # Rule 2: Turn off lights if lux above high threshold (hysteresis)
        # But only if it's been on for minimum dwell time
        elif lux > self.lux_high:
            key = f"light_{zone}_off"
            if self._check_dwell(key, timestamp):
                results.append(RuleResult(
                    rule_name="lights_off_high_lux",
                    fired=True,
                    action="off",
                    reason=f"Lux ({lux:.0f}) > {self.lux_high} (hysteresis)",
                    device_id=f"LIGHT-{zone}",
                    device_type="light",
                    zone=zone,
                    timestamp=timestamp
                ))

        # Rule 3: Vacancy timeout - turn off after no occupancy
        elif occupancy < self.occupancy_min:
            key = f"light_{zone}_vacancy"
            if self._check_dwell(key, timestamp, self.vacancy_timeout):
                results.append(RuleResult(
                    rule_name="lights_off_vacancy",
                    fired=True,
                    action="off",
                    reason=f"No occupancy ({occupancy} people) for {self.vacancy_timeout}s",
                    device_id=f"LIGHT-{zone}",
                    device_type="light",
                    zone=zone,
                    timestamp=timestamp
                ))

        return results

    def evaluate_fans(self, zone: str, reading, timestamp: datetime) -> List[RuleResult]:
        """Evaluate fan control rules for a zone."""
        results = []

        # Get sensor values, falling back to last good value on dropout
        temp = self._get_last_good(f"temperature_{zone}", reading.temperature)
        occupancy = self._get_last_good(f"occupancy_{zone}", reading.occupancy)
        co2 = self._get_last_good(f"co2_{zone}", reading.co2)

        if temp is None or occupancy is None:
            return results

        # Determine target fan speed
        target_speed = 0

        # Rule 1: Temperature-based
        if temp >= self.temp_on:
            if temp >= 30:
                target_speed = max(target_speed, 3)
            elif temp >= 28:
                target_speed = max(target_speed, 2)
            else:
                target_speed = max(target_speed, 1)

        # Rule 2: CO2 override
        if co2 is not None and co2 >= self.co2_limit:
            target_speed = max(target_speed, self.min_fan_speed + 1)

        # Rule 3: Occupancy - minimum ventilation
        if occupancy >= self.occupancy_min:
            target_speed = max(target_speed, self.min_fan_speed)

        # Rule 4: Hysteresis - don't turn off until temp drops below temp_off
        if target_speed == 0:
            if temp <= self.temp_off:
                target_speed = 0  # Can turn off

        # Apply dwell time check for state changes
        key = f"fan_{zone}_speed"
        if self._check_dwell(key, timestamp):
            results.append(RuleResult(
                rule_name="fan_speed_set",
                fired=True,
                action=f"speed_{target_speed}",
                reason=f"Temp: {temp:.1f}°C (on>{self.temp_on}, off<{self.temp_off}), "
                       f"CO2: {co2 if co2 is not None else 'N/A'}ppm (limit:{self.co2_limit}), "
                       f"Occupancy: {occupancy if occupancy is not None else 'N/A'}",
                device_id=f"FAN-{zone}",
                device_type="fan",
                zone=zone,
                timestamp=timestamp
            ))

        return results

    def _check_dwell(self, key: str, timestamp: datetime, custom_dwell: Optional[int] = None) -> bool:
        """Check if enough time has passed since last state change."""
        dwell = custom_dwell or self.dwell_time
        if key not in self.last_action_time:
            self.last_action_time[key] = timestamp
            return True
        elapsed = (timestamp - self.last_action_time[key]).total_seconds()
        if elapsed >= dwell:
            self.last_action_time[key] = timestamp
            return True
        return False

    def set_thresholds(self, **kwargs) -> None:
        """Update threshold values dynamically."""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)

    def get_thresholds(self) -> dict:
        """Get current threshold values."""
        return {
            'lux_low': self.lux_low,
            'lux_high': self.lux_high,
            'vacancy_timeout': self.vacancy_timeout,
            'temp_on': self.temp_on,
            'temp_off': self.temp_off,
            'co2_limit': self.co2_limit,
            'min_fan_speed': self.min_fan_speed,
            'occupancy_min': self.occupancy_min,
            'dwell_time': self.dwell_time
        }