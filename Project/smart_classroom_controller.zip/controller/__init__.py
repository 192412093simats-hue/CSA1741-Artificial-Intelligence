"""Controller package for the Smart Classroom Controller."""

from .agent import ControllerAgent, Decision, DeviceCommand
from .rules import RuleEngine, RuleResult
from .filters import SensorFilterPipeline, FilteredReading, SensorValidator
from .baseline import get_baseline, AlwaysOnBaseline, TimerBaseline, NaiveThresholdBaseline
from .logger import DecisionLogger, DecisionLog, log_decision

__all__ = [
    "ControllerAgent",
    "Decision",
    "DeviceCommand",
    "RuleEngine",
    "RuleResult",
    "SensorFilterPipeline",
    "FilteredReading",
    "SensorValidator",
    "get_baseline",
    "AlwaysOnBaseline",
    "TimerBaseline",
    "NaiveThresholdBaseline",
    "DecisionLogger",
    "DecisionLog",
    "log_decision",
]