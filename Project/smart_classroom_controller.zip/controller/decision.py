"""Manual (immediate) per-zone decision helper.

Manual mode is event-driven: every seat click / slider change calls
``decide_zone_state`` once per zone. Unlike :class:`RuleEngine` there is NO
dwell time and NO vacancy timeout -- the controller reacts instantly.

The thresholds come from ``config/thresholds.yaml`` (same file the rule
engine uses), so the manual rule and the auto rule engine never drift apart.
"""

from typing import Any, Dict, Optional


def _load_thresholds(thresholds: Optional[dict]) -> dict:
    if thresholds is not None:
        return thresholds
    import yaml
    with open("config/thresholds.yaml", "r") as f:
        return yaml.safe_load(f) or {}


def decide_zone_state(
    zone: str,
    occupied: Optional[int],
    outside_lux: Optional[float],
    temperature: Optional[float],
    co2: Optional[float],
    thresholds: Optional[dict] = None,
) -> Dict[str, Any]:
    """Decide the light + fan state for one zone immediately.

    Returns a dict with:
        zone, light_on, light_action, light_reason, light_rule,
        fan_speed (0..3), fan_reason, fan_rule

    Never raises on None inputs -- a None sensor value simply yields
    "light off / fan speed 0" with a readable reason.
    """
    cfg = _load_thresholds(thresholds)
    lights = cfg.get("lights", {}) or {}
    fans = cfg.get("fans", {}) or {}
    occ_cfg = cfg.get("occupancy", {}) or {}

    lux_low = lights.get("lux_low", 300)
    temp_on = fans.get("temp_on", 26.0)
    co2_limit = fans.get("co2_limit", 1000)
    min_speed = fans.get("min_speed", 1)

    occ = int(occupied) if occupied is not None else 0
    occ_min = int(occ_cfg.get("occupancy_min", 1))
    is_occupied = occ >= occ_min

    # ------------------------------------------------------------------ light
    if not is_occupied:
        light_on = False
        light_action = "off"
        light_reason = f"No occupancy ({occ} people)"
        light_rule = "lights_off_vacancy"
    elif outside_lux is None:
        light_on = False
        light_action = "off"
        light_reason = "No lux reading"
        light_rule = "lights_off_no_sensor"
    elif outside_lux < lux_low:
        light_on = True
        light_action = "on"
        light_reason = f"Occupied ({occ} people) and lux {outside_lux:.0f} < {lux_low}"
        light_rule = "lights_on_low_lux"
    else:
        light_on = False
        light_action = "off"
        light_reason = f"Lux {outside_lux:.0f} >= {lux_low} (daylight sufficient)"
        light_rule = "lights_off_high_lux"

    # -------------------------------------------------------------------- fan
    fan_speed = 0
    fan_rule = "fan_off"
    if temperature is not None:
        if temperature >= 30:
            fan_speed = 3
        elif temperature >= 28:
            fan_speed = 2
        elif temperature >= temp_on:
            fan_speed = 1
    if co2 is not None and co2 >= co2_limit:
        fan_speed = max(fan_speed, min_speed + 1)
        fan_rule = "fan_co2_override"
    if is_occupied:
        fan_speed = max(fan_speed, min_speed)

    if fan_speed == 0:
        if temperature is not None:
            fan_reason = f"Temp {temperature:.1f}°C below {temp_on}°C"
        else:
            fan_reason = "No temperature reading"
    else:
        parts = []
        if temperature is not None:
            parts.append(f"Temp {temperature:.1f}°C")
        parts.append(f"occupancy {occ}")
        if co2 is not None:
            parts.append(f"CO2 {co2:.0f}ppm")
        fan_reason = ", ".join(parts)

    return {
        "zone": zone,
        "light_on": light_on,
        "light_action": light_action,
        "light_reason": light_reason,
        "light_rule": light_rule,
        "fan_speed": fan_speed,
        "fan_reason": fan_reason,
        "fan_rule": fan_rule,
    }