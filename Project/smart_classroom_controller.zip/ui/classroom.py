"""Classroom hero: whiteboard bar, three zone cards with clickable seat grids.

Each zone card is a real ``st.container(border=True)`` holding a header row
(zone pill + two light indicators + one fan indicator) and a 2 x 8 seat grid
of real ``st.button`` widgets. In Manual mode seats toggle on click; in Auto
mode they are disabled and mirror the simulator occupancy.
"""

import streamlit as st

ZONES = ["front", "middle", "back"]
SEATS_PER_ZONE = 16  # 2 rows x 8 columns per zone


def _seat_label(occupied: bool) -> str:
    return "👤" if occupied else ""


def _light_indicator(n: int, on: bool) -> str:
    label = f"L{n} {'ON' if on else 'OFF'}"
    cls = "light-on" if on else "light-off"
    return f'<span class="light-indicator {cls}"><span class="bulb">💡</span>{label}</span>'


def _fan_indicator(speed: int) -> str:
    on = bool(speed)
    cls = "fan-on" if on else "fan-off"
    return f'<span class="fan-indicator {cls}"><span class="fan-icon">🌀</span>Fan: Speed {speed}</span>'


def render_zone_card(zone: str, state: dict, manual: bool, on_seat_toggle) -> None:
    """One zone card: header pill + L1 / L2 lights + fan, then a seat grid."""
    with st.container(border=True):
        # Header row: zone pill | L1 | L2 | Fan
        hc = st.columns([1.0, 1.0, 1.0, 2.2])
        dev = state["devices"]
        light_on = bool(dev.get(f"LIGHT-{zone}", {}).get("on", False))
        fan_speed = int(dev.get(f"FAN-{zone}", {}).get("speed", 0) or 0)
        with hc[0]:
            st.markdown(f'<span class="zone-pill">{zone.capitalize()}</span>', unsafe_allow_html=True)
        with hc[1]:
            st.markdown(_light_indicator(1, light_on), unsafe_allow_html=True)
        with hc[2]:
            st.markdown(_light_indicator(2, light_on), unsafe_allow_html=True)
        with hc[3]:
            st.markdown(_fan_indicator(fan_speed), unsafe_allow_html=True)

        # Seat grid: 2 rows x 8 columns
        seats = state["seats"][zone]
        for row in range(2):
            cols = st.columns(8)
            for col in range(8):
                i = row * 8 + col
                occ = bool(seats[i])
                with cols[col]:
                    st.button(
                        _seat_label(occ),
                        key=f"seat_{zone}_{i}",
                        on_click=on_seat_toggle,
                        args=(zone, i),
                        type="primary" if occ else "secondary",
                        disabled=not manual,
                        help=f"Seat {zone[0].upper()}{i+1} - click to toggle",
                        use_container_width=True,
                    )


def render_whiteboard_bar() -> None:
    st.markdown(
        '<div class="wb-bar">'
        '<span class="wb-item">📋 Whiteboard</span>'
        '<span class="wb-item wb-item--desk">🏫 Teacher Desk</span>'
        '</div>',
        unsafe_allow_html=True,
    )


def render_classroom(state: dict, manual: bool, on_seat_toggle) -> None:
    """Full classroom hero: whiteboard bar then three zone cards stacked."""
    render_whiteboard_bar()
    for zone in ZONES:
        render_zone_card(zone, state, manual, on_seat_toggle)


def render_outside_light_card(outside_lux) -> None:
    """Sun card with the outside lux plus a small ON / OFF / Dimmed legend."""
    lux_txt = f"{int(round(outside_lux))} lux" if outside_lux is not None else "--"
    st.markdown(
        f'<div class="outside-card">'
        f'<span class="sun">☀️</span>'
        f'<div class="outside-lux">{lux_txt}</div>'
        f'<div class="outside-label">Outside light</div>'
        f'</div>',
        unsafe_allow_html=True,
    )
    st.markdown(
        '<div class="legend-card">'
        '<div class="legend-title">Legend</div>'
        '<div class="legend-row"><span class="bulb light-on">💡</span> ON</div>'
        '<div class="legend-row"><span class="bulb light-off">💡</span> OFF</div>'
        '<div class="legend-row"><span class="bulb light-dim">💡</span> Dimmed</div>'
        '</div>',
        unsafe_allow_html=True,
    )
