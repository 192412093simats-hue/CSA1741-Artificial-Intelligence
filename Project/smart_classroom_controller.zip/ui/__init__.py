"""UI package for the Smart Classroom Controller dashboard."""
