"""KPI row, decision-log card, energy card, and bottom-strip cards.

All metrics reuse :mod:`evaluation.metrics` -- no duplicated metric logic here.
"""

from typing import Dict, List


def kpi_row(occupancy, inside_lux, temperature, co2) -> str:
    """Four big KPI cards: Occupancy / Light Level / Temperature / CO2."""
    return (
        '<div class="kpi-row">'
        f'{_kpi("👥", occupancy, "Occupancy")}'
        f'{_kpi("☀️", inside_lux, "Light Level (lux)")}'
        f'{_kpi("🌡️", temperature, "Temperature (°C)")}'
        f'{_kpi("💨", co2, "CO₂ (ppm)")}'
        "</div>"
    )


def _kpi(icon: str, value, label: str) -> str:
    v = value if value is not None else "--"
    return (
        f'<div class="kpi-card">'
        f'<span class="kpi-icon">{icon}</span>'
        f'<div><div class="kpi-value">{v}</div>'
        f'<div class="kpi-label">{label}</div></div></div>'
    )


def decision_log_card(decisions: List[Dict]) -> str:
    """Last 5 decisions newest first: '10:30 | Front lights ON | ...'."""
    shown = list(decisions)[-5:]
    shown.reverse()
    rows = []
    for d in shown:
        rows.append(
            f'<div class="reason-row">'
            f'<span class="dot"></span>'
            f'<span>{d["time"]} | {d["action"]}</span>'
            f'<span style="color:#8FA3C4;white-space:nowrap">• {d["reason"]}</span>'
            f"</div>"
        )
    body = "".join(rows) or '<span style="color:#8FA3C4">No decisions yet</span>'
    return (
        f'<div class="card"><div class="card-title">📋 Why did the controller act?</div>{body}</div>'
    )


def _energy_fmt(kwh: float) -> str:
    """kWh for a full day, Wh for the short windows the dashboard shows."""
    if kwh < 1.0:
        return f"{kwh * 1000:.1f} Wh"
    return f"{kwh:.3f} kWh"


def energy_card(base_kwh: float, ctrl_kwh: float, manual_mode: bool,
                pct_saved: float, ctrl_watts: float = None,
                base_watts: float = None) -> str:
    """Horizontal Baseline vs Controller bar with big saved percent."""
    if manual_mode:
        head = f'<div class="metric-big">{pct_saved:.0f}% less power right now</div>'
        sub = f'<div class="metric-sub">Controller {ctrl_watts:.0f} W vs baseline {base_watts:.0f} W</div>'
    else:
        head = f'<div class="metric-big">{pct_saved:.0f}% saved</div>'
        sub = (f'<div class="metric-sub">Baseline {_energy_fmt(base_kwh)} '
               f'vs Smart {_energy_fmt(ctrl_kwh)}</div>')
    bar = f'<div class="energy-bar"><div class="energy-fill" style="width:{min(100, pct_saved):.0f}%"></div></div>'
    return f'<div class="card"><div class="card-title">⚡ Energy</div>{head}{bar}{sub}</div>'


def bottom_strip(accuracy, latency, false_rate) -> str:
    """Three small cards: Decision Accuracy / Response Latency / False Activation Rate."""
    return (
        '<div class="bottom-strip">'
        f'{_metric_card("🎯", "Decision Accuracy", accuracy)}'
        f'{_metric_card("⏱️", "Response Latency", latency)}'
        f'{_metric_card("⚠️", "False Activation Rate", false_rate)}'
        "</div>"
    )


def _metric_card(icon: str, title: str, big) -> str:
    return (
        f'<div class="metric-card">'
        f'<div class="metric-title">{title}</div>'
        f'<div class="metric-big">{big}</div>'
        f"</div>"
    )
