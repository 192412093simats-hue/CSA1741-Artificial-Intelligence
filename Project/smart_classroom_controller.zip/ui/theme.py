"""Theme helpers: shared colors and the custom dark CSS block injected into Streamlit."""

DARK = {
    "bg": "#0A1020",
    "panel": "#111B30",
    "border": "#1E2D4A",
    "text": "#E8F0FF",
    "text_muted": "#8FA3C4",
    "teal": "#19E3C4",
    "amber": "#FFC83D",
    "purple": "#B58CFF",
    "danger": "#EF6A6A",
    "light_on": "#FFE89A",
    "fan_on": "#3DA9D8",
}

# One CSS block, injected once via st.markdown(..., unsafe_allow_html=True).
# Fonts >= 14 px everywhere; hides the Streamlit Deploy button + footer.
STYLESHEET = """
<style>
  /* ---- base readability ---- */
  html, body, .block-container { font-size: 14px !important; }
  body { background: #0A1020; color: #E8F0FF; }
  #MainMenu { visibility: hidden; }
  footer { visibility: hidden; }
  /* ---- Streamlit running / toolbar chrome ---- */
  div[data-testid="stDecoration"] { display: none !important; }
  button[kind="header"] { display: none !important; }
  div[data-testid="stToolbar"] { display: none !important; }

  /* ---- header ---- */
  .hdr { display: flex; align-items: center; gap: 0.8rem; }
  .hdr-icon { font-size: 2.2rem; line-height: 1; }
  .hdr-title { font-size: 1.8rem; font-weight: 700; color: #E8F0FF; line-height: 1.1; }
  .hdr-sub { font-size: 0.95rem; color: #8FA3C4; }
  .chips { display: flex; gap: 0.6rem; justify-content: flex-end; flex-wrap: wrap; }
  .chip { background: #1E2D4A; border-radius: 999px; padding: 0.35rem 0.9rem;
          font-size: 0.9rem; color: #E8F0FF; font-weight: 600; }
  .mode-chip { background: rgba(25,227,196,0.15); border: 1px solid #19E3C4;
               color: #19E3C4; border-radius: 999px; padding: 0.35rem 0.9rem;
               font-size: 0.95rem; font-weight: 700; }

  /* ---- KPI row ---- */
  .kpi-row { display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap; }
  .kpi-card { background: #111B30; border: 1px solid #1E2D4A; border-radius: 14px;
              padding: 1rem 1.4rem; box-shadow: 0 2px 12px rgba(0,0,0,0.4);
              display: flex; align-items: center; gap: 0.9rem; flex: 1 1 200px; }
  .kpi-icon { font-size: 1.8rem; line-height: 1; }
  .kpi-value { font-size: 1.7rem; font-weight: 700; color: #E8F0FF; line-height: 1; }
  .kpi-label { font-size: 0.9rem; color: #8FA3C4; margin-top: 0.35rem; }

  /* ---- generic card ---- */
  .card { background: #111B30; border: 1px solid #1E2D4A; border-radius: 14px;
          padding: 1rem 1.2rem; box-shadow: 0 2px 12px rgba(0,0,0,0.4); }
  .card-title { font-size: 1.05rem; font-weight: 700; color: #E8F0FF; margin-bottom: 0.6rem; }

  /* ---- classroom hero ---- */
  .wb-bar { display: flex; gap: 1rem; justify-content: center; margin-bottom: 0.7rem; }
  .wb-item { background: #E8F0FF; color: #0A1020; font-weight: 700; font-size: 0.95rem;
             border-radius: 6px; padding: 0.35rem 1.6rem; }
  .wb-item--desk { background: #C79A6B; color: #0A1020; }
  .wb-item.desk { background: #C79A6B; }

  .zone-pill { display: inline-block; background: rgba(25,227,196,0.12); color: #19E3C4;
               border: 1px solid #19E3C4; border-radius: 999px; padding: 0.25rem 0.9rem;
               font-size: 1rem; font-weight: 700; }
  .light-indicator { display: inline-flex; align-items: center; gap: 0.35rem;
                     font-size: 0.95rem; font-weight: 700; }
  .light-indicator .bulb { font-size: 1.1rem; }
  .light-on { color: #FFC83D; text-shadow: 0 0 8px rgba(255,200,61,0.8); }
  .light-off { color: #5A6682; }
  .fan-indicator { display: inline-flex; align-items: center; gap: 0.35rem;
                   font-size: 0.95rem; font-weight: 700; }
  .fan-on { color: #19E3C4; }
  .fan-on .fan-icon { display: inline-block; animation: fanSpin 1s linear infinite; }
  .fan-off { color: #5A6682; }
  @keyframes fanSpin { to { transform: rotate(360deg); } }

  /* seats: real st.button widgets; occupied = primary teal + glow, empty = secondary grey */
  .seat-grid button { min-height: 42px; font-size: 1.05rem; border-radius: 8px; }
  button[kind="primary"] { box-shadow: 0 0 14px rgba(25,227,196,0.75) !important;
                           border-color: #19E3C4 !important; }

  /* ---- outside light + legend ---- */
  .outside-card { background: #111B30; border: 1px solid #1E2D4A; border-radius: 14px;
                  padding: 1rem 1.2rem; text-align: center; box-shadow: 0 2px 12px rgba(0,0,0,0.4); }
  .outside-card .sun { font-size: 2.2rem; }
  .outside-lux { font-size: 1.6rem; font-weight: 700; color: #E8F0FF; }
  .outside-label { font-size: 0.9rem; color: #8FA3C4; }
  .legend-card { background: #111B30; border: 1px solid #1E2D4A; border-radius: 12px;
                 padding: 0.9rem 1rem; margin-top: 0.8rem; }
  .legend-title { font-size: 1rem; font-weight: 700; color: #E8F0FF; margin-bottom: 0.5rem; }
  .legend-row { display: flex; align-items: center; gap: 0.5rem; font-size: 0.95rem;
                color: #E8F0FF; padding: 0.2rem 0; }

  /* ---- decision log ---- */
  .reason-row { display: grid; grid-template-columns: auto 1.1fr 1.6fr; gap: 0.4rem 0.6rem;
                padding: 0.35rem 0; font-size: 0.95rem; align-items: center; }
  .reason-row .dot { width: 8px; height: 8px; border-radius: 50%; background: #19E3C4; }

  /* ---- energy bar ---- */
  .energy-bar { height: 12px; background: #1E2D4A; border-radius: 6px; overflow: hidden;
                margin: 0.5rem 0; }
  .energy-fill { height: 100%; background: linear-gradient(90deg, #19E3C4, #FFC83D); }

  /* ---- bottom strip ---- */
  .bottom-strip { display: flex; gap: 1rem; flex-wrap: wrap; }
  .metric-card { background: #111B30; border: 1px solid #1E2D4A; border-radius: 14px;
                 padding: 1rem 1.4rem; box-shadow: 0 2px 12px rgba(0,0,0,0.4); flex: 1 1 220px; }
  .metric-title { font-size: 0.95rem; color: #8FA3C4; margin-bottom: 0.4rem; }
  .metric-big { font-size: 1.6rem; font-weight: 700; color: #E8F0FF; line-height: 1.1; }
  .metric-sub { font-size: 0.9rem; color: #8FA3C4; }

  /* ---- zone containers: teal dashed border ----
     st-emotion-cache-tg52rz is Streamlit 1.36's class for st.container(border=True),
     so only the three zone cards match (not the 74 generic block wrappers). */
  div[data-testid="stVerticalBlockBorderWrapper"].st-emotion-cache-tg52rz {
      border: 1px dashed #19E3C4 !important;
      border-radius: 12px !important;
      background: rgba(25,227,196,0.03) !important; }
  .light-dim { color: #C9A227; text-shadow: 0 0 6px rgba(255,200,61,0.35); }
</style>
"""
