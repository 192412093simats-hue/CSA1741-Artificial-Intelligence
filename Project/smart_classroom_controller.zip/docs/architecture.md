# System Architecture

## Overview

The Smart Classroom Controller is designed with a modular, layered architecture that separates concerns and allows for easy testing, maintenance, and extension.

## Architecture Diagram

```
                                    +-------------------+
                                    |  Streamlit App   |
                                    |  (User Interface) |
                                    +-------------------+
                                             |
                                             | HTTP/WebSocket
                                             |
                                     +-------------------+
                                     |   Streamlit      |
                                     |   (Server)       |
                                     +-------------------+
                                             |
                                             | Function Calls
                                             |
+----------------------+   +-------------------+   +-------------------+   +-------------------+
|  Evaluation Module    |   |  Controller      |   |  IoT Simulator    |   |  Configuration    |
|  - Metrics            |   |  - Agent         |   |  - Classroom      |   |  - Thresholds     |
|  - Report Generator   |   |  - Rules         |   |  - Devices        |   |  - Scenarios      |
|  - Evaluation Harness |   |  - Filters       |   |  - Sensors        |   |                  |
+----------------------+   +-------------------+   +-------------------+   +-------------------+
                                             |
                                             | Async/Coroutine
                                             |
                                     +-------------------+
                                     |   Python Backend  |
                                     |   (FastAPI/Flask) |
                                     +-------------------+
                                             |
                                             | gRPC/HTTP
                                             |
                             +-----------------------------+
                             |      Cloud Services          |
                             |  - Monitoring                |
                             |  - Logging                   |
                             |  - Metrics Collection       |
                             +-----------------------------+
```

## Layer 1: User Interface (Streamlit)

The Streamlit app provides:
- **Real-time Visualization**: Interactive floor plan and live sensor charts
- **Control Panel**: Scenario selection, simulation speed, noise control, threshold tuning
- **Manual Override**: Direct device control for testing and special scenarios
- **Evaluation Harness**: Run batch evaluations across multiple seeds and scenarios
- **Report Generation**: PDF and Markdown test reports with embedded charts

**Technologies**: Streamlit, Plotly, Matplotlib, ReportLab

## Layer 2: Backend Services

Python services that provide core functionality via API endpoints or direct function calls:

### Controller Module
**Responsibility**: Decision logic and device control
- **Rule Engine**: Threshold-based decision making with hysteresis and dwell time
- **Filter Pipeline**: Sensor validation, outlier rejection, noise smoothing
- **Device Management**: Virtual devices (lights, fans, AC) with power tracking
- **Manual Override**: Temporary mode for testing and special scenarios
- **Decision Logging**: Complete audit trail with explanations

**Technologies**: Python dataclasses, dataclasses, asyncio

### IoT Simulator Module
**Responsibility**: Realistic sensor data generation
- **Sensor Models**: Occupancy ( PIR + count), ambient light, temperature, humidity, CO2
- **Fault Injection**: Gaussian noise, dropouts, spikes, sensor drift
- **Ground Truth**: Noise-free ideal values for evaluation
- **Scenario Engine**: Time-based occupancy patterns and environmental conditions

**Technologies**: NumPy, YAML configuration, dataclasses

### Evaluation Module
**Responsibility**: Performance measurement and reporting
- **Metrics Calculation**: Accuracy, latency, energy savings, false activation rates
- **Batch Harness**: Multiple seeded simulations across scenarios
- **Report Generation**: Automated PDF/Markdown reports with charts
- **Comparison**: Controller vs baseline performance

**Technologies**: pytest, NumPy, ReportLab, Matplotlib

## Layer 3: Configuration

### Thresholds Configuration (`config/thresholds.yaml`)
```yaml
lights:
  lux_low: 300                    # Light ON threshold (lux)
  lux_high: 500                   # Light OFF threshold (lux)
  vacancy_timeout_seconds: 120    # Time before lights turn off
  dimming_step: 25                # % per adjustment

fans:
  temp_on: 26.0                   # Fan ON temperature (°C)
  temp_off: 24.0                  # Fan OFF temperature (°C)
  co2_limit: 1000                 # CO2 ventilation limit (ppm)

occupancy:
  occupancy_min: 1                # Minimum occupancy for "occupied"

general:
  dwell_time_seconds: 30          # Minimum on/off dwell time
  sensor_timeout_seconds: 30      # Sensor dropout timeout
```

### Scenario Configuration (`config/scenarios.yaml`)
```yaml
scenarios:
  normal_day:
    description: Typical school day
    schedule:
      - ["7:30", empty]
      - ["8:00", arrival]
      - ["9:00", lecture]
      - ["11:00", break]
      - ["11:30", lecture]
      - ["13:00", departure]
      - ["14:00", empty]
    base_occupancy: 30
    base_temp: 25.0
    base_humidity: 55.0
    base_co2: 600
    base_lux: 400
    noise_level: 1.0
    fault_probability: 0.01
```

## Communication Patterns

### Event-Driven Architecture
- **Sensor Updates**: Emit new sensor readings every simulation minute
- **Device Commands**: Controller sends commands to virtual devices
- **Decision Events**: Controller logs decisions with full context
- **Evaluation Events**: Completed simulations trigger metrics calculation

### Data Flow
1. **User Interaction** → Streamlit App
2. **Configuration Changes** → Backend Services
3. **Sensor Generation** → IoT Simulator
4. **Decision Making** → Controller Agent
5. **Device State Updates** → UI Visualization
6. **Metrics Collection** → Evaluation Module
7. **Reports** → User Download

## Error Handling

1. **Sensor Dropout**: Automatic fallback to last good value
2. **Invalid Readings**: Clamp to valid ranges, mark as invalid
3. **Controller Failures**: Graceful degradation, manual override mode
4. **Evaluation Failures**: Isolated per-scenario, continue with other scenarios

## Extensibility

### Adding New Sensors
1. Extend `SensorReading` dataclass
2. Implement sensor simulation in `iot_simulator`
3. Add sensor validation rules in `filters.py`
4. Update threshold configuration in `config/thresholds.yaml`

### Adding New Devices
1. Extend `Device` class in `devices.py`
2. Implement device-specific logic for power calculation
3. Update controller to handle new device type
4. Add device controls in Streamlit UI

### Adding New Scenarios
1. Add scenario definition in `config/scenarios.yaml`
2. Implement schedule parsing in `scenarios.py`
3. Update ground truth generation as needed

## Testing Strategy

1. **Unit Tests**: Each module tested in isolation
2. **Integration Tests**: Module interactions verified
3. **End-to-End Tests**: Complete simulation scenarios validated
4. **Performance Tests**: Evaluation harness timing and resource usage

## Performance Considerations

1. **Simulation Speed**: Configurable speed multiplier (real-time to 100x faster)
2. **Memory Usage**: Incremental processing, bounded history retention
3. **API Responsiveness**: Async operations for non-blocking UI
4. **Evaluation Parallelism**: Independent simulations can run in parallel

## Future Enhancements

1. **Machine Learning**: Adaptive thresholds based on occupancy patterns
2. **Real IoT Integration**: ESP32/Arduino device drivers
3. **Cloud Storage**: Persistent simulation results and reports
4. **Mobile App**: Remote monitoring and control
5. **Energy Analytics**: Predictive energy consumption and optimization

## Monitoring and Observability

- **Decision Log**: Complete audit trail of all controller decisions
- **Performance Metrics**: Real-time monitoring of system performance
- **Error Tracking**: Automatic error reporting and alerting
- **Resource Monitoring**: Memory usage, CPU utilization, simulation speed

## Security Considerations

- **Input Validation**: All sensor and configuration inputs validated
- **Manual Override Protection**: Prevents unauthorized device control
- **Rate Limiting**: Prevents API abuse and excessive simulation requests
- **Data Privacy**: No personal data collected or stored