# AI-Powered Smart Classroom Controller - Test Report

**Generated:** 2026-11-14 11:18:29

**Project:** AI-Powered Smart Classroom Controller
**Version:** 1.0.0

## 1. Abstract and Objectives

This document describes the AI-Powered Smart Classroom Controller, a prototype that recommends or simulates 
lighting and fan control in a classroom based on occupancy and environmental inputs.

### Objectives

1. Build an end-to-end prototype with simulated IoT sensors and virtual devices.
2. Implement transparent, threshold-based, rule-based control with hysteresis and dwell time.
3. Evaluate decision accuracy, response latency, energy savings, and false activation rate.
4. Generate interactive Streamlit dashboard and automated test reports.

## 2. System Architecture

The system consists of: IoT Sensor Simulation Module, Control Logic Module, Evaluation Module, and Streamlit App.

## 3. Module Descriptions

### Module 1: Sensor/Input Simulation

The IoT simulator generates occupancy, ambient light, temperature, humidity, and CO2 readings with 
configurable noise, dropouts, spikes, and drift. Ground truth values are computed for validation.

### Module 2: Decision Rules and Control

The controller applies threshold-based rules with hysteresis and minimum dwell time to control lights and fans.

### Module 3: System Testing and Evaluation

The evaluation harness runs seeded simulations across multiple scenarios and computes accuracy, latency, energy savings, and false activation rates.

## 4. Results

### 4.1 Decision Accuracy
### Scenario: normal_day

- Average Decision Accuracy: 1.0000
- Average Precision: 0.0000
- Average Recall: 0.0000
- Average F1 Score: 0.0000
- Average Fan Accuracy: 1.0000
- Average Fan Precision: 1.0000
- Average Fan Recall: 1.0000
- Average Fan F1: 1.0000
- Average Energy Saving: 88.89%
- Average False Activation Rate: 0.0000

### Scenario: exam_day

- Average Decision Accuracy: 1.0000
- Average Precision: 0.0000
- Average Recall: 0.0000
- Average F1 Score: 0.0000
- Average Fan Accuracy: 0.8000
- Average Fan Precision: 0.8000
- Average Fan Recall: 0.8000
- Average Fan F1: 0.8000
- Average Energy Saving: 90.09%
- Average False Activation Rate: 0.0000

### Scenario: empty_weekend

- Average Decision Accuracy: 1.0000
- Average Precision: 0.0000
- Average Recall: 0.0000
- Average F1 Score: 0.0000
- Average Fan Accuracy: 1.0000
- Average Fan Precision: 0.0000
- Average Fan Recall: 0.0000
- Average Fan F1: 0.0000
- Average Energy Saving: 100.00%
- Average False Activation Rate: 0.0000

### Scenario: hot_afternoon

- Average Decision Accuracy: 1.0000
- Average Precision: 0.0000
- Average Recall: 0.0000
- Average F1 Score: 0.0000
- Average Fan Accuracy: 1.0000
- Average Fan Precision: 1.0000
- Average Fan Recall: 1.0000
- Average Fan F1: 1.0000
- Average Energy Saving: 66.67%
- Average False Activation Rate: 0.0000

### Scenario: power_saving_mode

- Average Decision Accuracy: 1.0000
- Average Precision: 0.0000
- Average Recall: 0.0000
- Average F1 Score: 0.0000
- Average Fan Accuracy: 1.0000
- Average Fan Precision: 1.0000
- Average Fan Recall: 1.0000
- Average Fan F1: 1.0000
- Average Energy Saving: 88.89%
- Average False Activation Rate: 0.0000

### Scenario: faulty_sensor

- Average Decision Accuracy: 1.0000
- Average Precision: 0.0000
- Average Recall: 0.0000
- Average F1 Score: 0.0000
- Average Fan Accuracy: 1.0000
- Average Fan Precision: 1.0000
- Average Fan Recall: 1.0000
- Average Fan F1: 1.0000
- Average Energy Saving: 88.89%
- Average False Activation Rate: 0.0000

### 4.2 Energy Savings

Energy savings achieved: 87.24%

## 5. User Interface

The Streamlit dashboard is a single page: a sidebar mode switcher plus a header, KPI row, classroom hero, decision log + energy cards, and a bottom metrics strip; tabs split it into Live Dashboard and Evaluation.

### Sidebar — Mode switcher
Mode radio with exactly two options: "Manual - click the seats" and "Auto - run simulation".
In Manual mode the sidebar shows an Outside light (lux) slider (0-1000, default 600), a Room temperature slider (20-40 °C, default 28), and "Fill all seats" / "Clear all seats" buttons. No speed slider, thresholds, noise, fault toggles, or seed controls.
In Auto mode the sidebar shows a Scenario dropdown (Normal Day, Exam Day, Hot Afternoon, Empty Weekend) plus Start / Pause / Reset buttons.

### Header
Graduation-cap icon with title "Smart Classroom Controller" and subtitle "AI-Powered Rule-Based Lighting & Fan Control". Right side shows a Mode chip (MANUAL / AUTO).

### KPI Row
Four cards: Occupancy (people), Light Level (lux) = outside lux + 150 per lit zone, Temperature (°C), CO₂ (ppm) = 400 + 15 × occupancy.

### Classroom hero
Whiteboard / Teacher Desk bar, then three zone cards (Front / Middle / Back), each with a teal dashed border, zone pill, L1/L2 light indicators (ON/OFF), a fan indicator (Speed 0..3), and a 2×8 grid of real clickable seat buttons (16 per zone, 48 total). Stable keys seat_{zone}_{index}. Seats toggle occupancy instantly in Manual mode and are disabled in Auto mode, where they mirror simulator occupancy.

### Outside light card
Sun icon card showing outside lux plus a legend card (ON / OFF / Dimmed).

### Decision Log
Last 5 decisions, newest first, showing time, action, and reason with teal dots.

### Energy card
Manual mode: "X% less power right now" with controller vs baseline watts. Auto mode: baseline vs smart kWh with percentage saved bar.

### Bottom strip
Three metric cards via evaluation/metrics.py: Decision Accuracy, Response Latency ("--" in Manual mode), False Activation Rate.

### Evaluation Tab
"Run evaluation" button runs the batch harness across the selected scenarios and shows a per-scenario results table plus a Decision Accuracy bar chart. "Download test report (PDF)" button serves docs/Test_Report.pdf.

## 6. Limitations and Future Work

This prototype uses simulated sensors and devices. Real IoT hardware integration is future work.

## 7. Dashboard Screenshots

![manual_one_seat.png](docs/screenshots/manual_one_seat.png)

![manual_full.png](docs/screenshots/manual_full.png)

![auto_running.png](docs/screenshots/auto_running.png)

## 8. Test Cases (pytest Results)

No pytest results provided.

---
*End of Report*