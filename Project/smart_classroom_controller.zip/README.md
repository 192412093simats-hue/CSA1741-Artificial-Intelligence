# Smart Classroom Controller

An AI-powered smart classroom controller that simulates IoT sensors, applies transparent threshold-based rules to control lights/fans, evaluates decisions against baselines, and shows a Streamlit dashboard.

## Dashboard Overview

The app is a single page split into **Live Dashboard** and **Evaluation** tabs. The user first chooses a **mode** from the sidebar:

- **Manual — click the seats**: mark students present by clicking seats in the classroom hero; the controller instantly decides lights/fans per zone and shows energy saved right now.
- **Auto — run simulation**: pick a scenario, start the simulator, and watch it drive the classroom (occupancy, lux, temperature, CO2) as the controller reacts.

## Run

```powershell
.venv\Scripts\Activate.ps1
streamlit run app.py        # http://localhost:8501
```

## Test / eval / report

```powershell
.venv\Scripts\python.exe -m pytest -v
.venv\Scripts\python.exe scripts/run_eval.py
.venv\Scripts\python.exe scripts/gen_reports.py
.venv\Scripts\python.exe scripts/ui_check.py   # Playwright UI acceptance
```

## Layout

- `app.py` — Streamlit page flow + session state (ONE state object).
- `ui/theme.py` — dark palette + STYLESHEET CSS.
- `ui/classroom.py` — zone cards + seat grid.
- `ui/cards.py` — KPI/log/energy/metrics cards.
- `controller/rules.py` — `decide_zone_state()` pure per-zone rule (Manual, immediate) + `RuleEngine` (Auto, dwell/hysteresis).
- `controller/agent.py` — ControllerAgent.
- `iot_simulator/` — sensors/devices/scenarios.
- `evaluation/metrics.py` — the ONLY metric implementations (reuse, never duplicate).
- `tests/test_rules.py` — includes TestManualDecisions.
- `config/thresholds.yaml`, `config/scenarios.yaml`.

## Dashboard Layout (top → bottom)

**Header + Mode chip** — title, subtitle, and a MANUAL / AUTO chip.

**Sidebar (mode radio)**:
- Manual mode: Outside lux slider (0–1000, default 600), Room temperature slider (20–40 °C, default 28), and **Fill all seats** / **Clear all seats** buttons.
- Auto mode: Scenario dropdown (Normal Day, Exam Day, Hot Afternoon, Empty Weekend) plus **Start / Pause / Reset**.

**KPI row (4 cards)** — Occupancy (people), Light Level (lux) = outside lux + 150 per lit zone, Temperature (°C), CO₂ (ppm) = 400 + 15 × occupancy.

**Classroom hero** — Whiteboard / Teacher Desk bar, then three zone cards (Front / Middle / Back) with teal dashed borders: zone pill, L1/L2 light indicators (ON/OFF), fan indicator (Speed 0–3), and a 2×8 grid of real clickable seat buttons (16 per zone, 48 total, keys `seat_{zone}_{index}`). Seats toggle occupancy instantly in Manual mode and are disabled in Auto mode, where they mirror simulator occupancy.

**Outside light card** — sun icon showing outside lux plus a legend card (ON / OFF / Dimmed).

**Decision Log** — last 5 decisions, newest first, with time/action/reason.

**Energy card** — Manual mode: "% less power right now" (controller vs baseline watts). Auto mode: baseline vs smart kWh with a percentage-saved bar.

**Bottom strip** — three metrics via `evaluation/metrics.py`: Decision Accuracy, Response Latency ("--" in Manual mode), False Activation Rate.

**Evaluation tab** — "Run evaluation" runs the batch harness across the selected scenarios and shows a per-scenario results table plus a Decision Accuracy bar chart; "Download test report (PDF)" serves docs/Test_Report.pdf.

## Running Tests

```powershell
# Full test suite (31 tests)
.venv\Scripts\python.exe -m pytest -v

# Run specific test file
.venv\Scripts\python.exe -m pytest tests/test_rules.py -v
```

All tests must pass before deploying.

## Running Evaluation

```powershell
# Run full evaluation across all 6 scenarios (5 sims each)
.venv\Scripts\python.exe scripts/run_eval.py

# Regenerate Markdown + PDF reports (docs/Test_Report.md + docs/Test_Report.pdf)
.venv\Scripts\python.exe scripts/gen_reports.py

# Playwright UI acceptance (requires Streamlit running on port 8501)
.venv\Scripts\python.exe scripts/ui_check.py
```

### Evaluation Results (final, seed=42)

| Scenario | Accuracy | Precision | Recall | F1 | Fan Accuracy | Energy Saving | False Act Rate |
|----------|----------|-----------|--------|----|--------------|---------------|----------------|
| normal_day | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 1.0000 | 88.89% | 0.0000 |
| exam_day | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 0.8000 | 90.09% | 0.0000 |
| empty_weekend | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 1.0000 | 100.00% | 0.0000 |
| hot_afternoon | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 1.0000 | 66.67% | 0.0000 |
| power_saving_mode | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 1.0000 | 88.89% | 0.0000 |
| faulty_sensor | 1.0000 | 0.0000 | 0.0000 | 0.0000 | 1.0000 | 88.89% | 0.0000 |

Average energy saving: 87.24%

## Design Decisions

1. **Rule-Based Architecture**: Chosen for transparency and explainability. Every decision is logged with the rule fired and the reason.
2. **Hysteresis**: Separate ON/OFF thresholds prevent device flapping (e.g., lights turn on at 300 lux but only turn off at 500 lux).
3. **Dwell Time**: Minimum on/off duration prevents rapid switching.
4. **Sensor Validation**: Median filter rejects outliers, moving average smooths noise, dropout handler falls back to last good value.
5. **Configurable Scenarios**: YAML-based scenario definitions allow easy addition of new scenarios.
6. **Deterministic Mode**: All simulations use a fixed random seed for reproducible tests.
7. **Inside lux / CO2 formulas**: Inside light level = outside lux + 150 × zones with the light ON; CO2 = 400 + 15 × occupancy (Manual) — these are deterministic rule outputs, not separate sensors.
8. **Manual mode is event-driven**: no loops; each click/slider runs `decide_zone_state` once per zone, vacancy immediate.
9. **Auto mode advances the simulator then `st.rerun()`** (Streamlit 1.36 has no `st.fragment`).
10. **Evaluation tab covers all 6 backend scenarios**; the sidebar Auto dropdown shows the 4 UI scenarios. Manual accuracy is compared against the ground-truth rule; latency shows "--" in Manual mode.
11. **L1/L2 indicators both mirror `LIGHT-<zone>`**; fan speed tiers mirror `rules.py` (26/28/30 °C, CO2 ≥ 1000 → ≥ 2).
12. **Scenario schedule semantics**: the applicable period is the LAST schedule entry whose start ≤ now; duration only bounds the final period. (Fixed `get_occupancy_at_time` first-match bug — see `tests/test_scenarios.py`.)
13. **Energy units**: Auto steps accumulate true kWh (Wh / 1000); the dashboard shows Wh when < 1 kWh.

## Key Metrics

| Metric | Description |
|--------|-------------|
| Decision Accuracy | % of timesteps where controller state matches ground truth |
| Response Latency | Time between condition change and device state change |
| Energy Saving | (Baseline kWh − Controller kWh) / Baseline kWh |
| False Activation Rate | % of activations that shouldn't have happened |

## Assumptions

- The classroom has 3 zones (front, middle, back) with lights and fans per zone.
- Sensors are simulated (no physical hardware required).
- Occupancy follows a class schedule pattern.
- Daylight follows a sinusoidal curve peaking at noon.
- CO2 rises linearly with occupancy.

## Files Deleted / Replaced

The old `ui/floorplan.py` (inline SVG floor plan) and `ui/components.py` are removed; their rendering lives in `ui/theme.py`, `ui/classroom.py`, and `ui/cards.py`. Removed `scripts/take_screenshots.py` and `scripts/check_svg.py` (replaced by `scripts/ui_check.py`).

## License

MIT License
